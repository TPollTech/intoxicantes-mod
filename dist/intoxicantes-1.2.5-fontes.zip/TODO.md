# TODO — Intoxicantes Mod (atualizado em v1.2.2)

O mercado, a economia e a fazenda estão completos e funcionais. O que sobra é lapidação:

## Próximos passos (ordem sugerida)

1. **(FEITO na v1.2.4)** Sons próprios: `soco_d12` (estouro da 12, item + Gago), `voz_gago`
   (blip de fala no ambient) e `zumbido_uv` (hum da lâmpada). Próximo passo sonoro, se
   quiser evoluir: sons de compra/venda no cardápio e punchline própria nos balins acertando.

2. **Partículas custom** — fumaça de baseado com cor própria, folhas caindo da planta
   madura, notas de R$ voando na venda. O pipeline de partícula do jogo aceita registro
   sem asset pesado.

3. **Mercado por bioma (fase 2)** — a roupa do Gago já varia (7 fantasias); o PRÉDIO não.
   Variações no gen_mercado.py (arenito no deserto, spruce na serra, telhado de cobre no
   brejo) fariam a loja nascer "do lugar".

4. **Texturas das bebidas** — as 16 consumíveis ainda têm a arte da primeira geração.
   O mesmo tratamento procedural que as sementes/plantações receberam.

5. **Game tests das conquistas** — as progressões novas (v1.2.2) merecem teste de
   award programático (compra → Freguês da Esquina).

## O que NÃO precisa mais fazer (já está pronto)
- Estrutura do mercado: gerada por template NBT próprio (nada de Structure Block manual)
- Loot dos NPCs: Gago (cachaça, cervejas, R$, cartuchos) e Traficante (estoque)
- Reparo da escopeta: componente REPAIRABLE com cartucho (bigorna)
- Validador de worldgen no build: JSON/NBT quebrado NÃO sobe pro jar
- Config: config/intoxicantes.json (escopeta, cotação da rua, UV)
- Conquistas: aba "O Esquinão" com 6 progressões
- 10 game tests de economia/estoque/escopeta (incl. teto de saldo e config da 12, v1.2.4)
