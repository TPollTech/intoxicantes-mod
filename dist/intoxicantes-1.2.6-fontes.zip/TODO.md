# TODO — Intoxicantes Mod (atualizado em v1.2.2)

O mercado, a economia e a fazenda estão completos e funcionais. O que sobra é lapidação:

## Próximos passos (ordem sugerida)

1. **(FEITO na v1.2.4 + v1.2.7)** Sons próprios: `soco_d12` (estouro da 12, item + Gago),
   `voz_gago` (blip de fala no ambient), `zumbido_uv` (hum da lâmpada) e, na v1.2.7,
   `caixa_registradora` (compra/venda) e `balim_acerto` (punchline no balim acertando).

2. **(FEITO na v1.2.7)** Partículas custom — nota de R$ na venda, folha da planta madura,
   fumaça verde-erva do baseado contínua enquanto puxa.

3. **Mercado por bioma (fase 2)** — a roupa do Gago já varia (7 fantasias); o PRÉDIO não.
   Variações no gen_mercado.py (arenito no deserto, spruce na serra, telhado de cobre no
   brejo) fariam a loja nascer "do lugar".

4. **Texturas das bebidas** — as 16 consumíveis ainda têm a arte da primeira geração.
   O mesmo tratamento procedural que as sementes/plantações receberam.

5. **(FEITO na v1.2.7)** Game tests das conquistas — fidelidade completa (raiz, tiers,
   descontos) e colheita perfeita validados por award programático.

## O que NÃO precisa mais fazer (já está pronto)
- Estrutura do mercado: gerada por template NBT próprio (nada de Structure Block manual)
- Loot dos NPCs: Gago (cachaça, cervejas, R$, cartuchos) e Traficante (estoque)
- Reparo da escopeta: componente REPAIRABLE com cartucho (bigorna)
- Validador de worldgen no build: JSON/NBT quebrado NÃO sobe pro jar
- Config: config/intoxicantes.json (escopeta, cotação da rua, UV)
- Conquistas: aba "O Esquinão" com 6 progressões
- 12 game tests de economia/estoque/escopeta/progressões (teto de saldo e config da 12
  na v1.2.4; fidelidade e colheita perfeita na v1.2.7)
