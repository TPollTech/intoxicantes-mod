package com.intoxicantes;

import java.util.HashSet;
import net.fabricmc.fabric.api.gametest.v1.GameTest;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.util.ProblemReporter;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.storage.TagValueOutput;

/** Exercises vanilla offers, actual NPC save data and the daily stock policy. */
public class CommerceGameTest {
    @GameTest
    public void immaturePlantsCannotGenerateSellableHarvest(GameTestHelper helper) {
        var crops = java.util.List.of(IntoxicantesMod.LOUPULO_PLANT, IntoxicantesMod.UVA_PLANT,
                IntoxicantesMod.CAFE_PLANT, IntoxicantesMod.MACONHA_PLANT, IntoxicantesMod.PAPOULA_PLANT);
        var seeds = java.util.List.of(IntoxicantesMod.SEMENTE_LOUPULO, IntoxicantesMod.SEMENTE_UVA,
                IntoxicantesMod.SEMENTE_CAFE, IntoxicantesMod.SEMENTE_MACONHA, IntoxicantesMod.SEMENTE_PAPOULA);
        for (int i = 0; i < crops.size(); i++) {
            var crop = (UvCropBlock) crops.get(i);
            var product = java.util.List.of(IntoxicantesMod.LOUPULO_FRESCO, IntoxicantesMod.UVA,
                    IntoxicantesMod.CAFE_VERDE, IntoxicantesMod.MACONHA_SEDA, IntoxicantesMod.OPIO).get(i);
            var state = crop.defaultBlockState().setValue(UvCropBlock.AGE, 0).setValue(UvCropBlock.UV_AGE, 0);
            var drops = net.minecraft.world.level.block.Block.getDrops(state, helper.getLevel(), helper.absolutePos(BlockPos.ZERO), null);
            helper.assertTrue(drops.stream().noneMatch(stack -> stack.is(product)), "Breaking seedlings must not create sellable products");
            final var seed = seeds.get(i);
            helper.assertTrue(drops.stream().filter(stack -> stack.is(seed)).mapToInt(ItemStack::getCount).sum() == 1,
                    "A seedling returns only its planted seed");
            state = state.setValue(UvCropBlock.AGE, 4);
            helper.assertTrue(crop.isRandomlyTicking(state), "Fully grown crop must still tick for UV ripening");
            drops = net.minecraft.world.level.block.Block.getDrops(state, helper.getLevel(), helper.absolutePos(BlockPos.ZERO), null);
            helper.assertTrue(drops.stream().filter(stack -> stack.is(product)).mapToInt(ItemStack::getCount).sum() == 1,
                    "Grown but unripe crop yields one product");
            state = state.setValue(UvCropBlock.UV_AGE, 3);
            helper.assertFalse(crop.isRandomlyTicking(state), "Fully ripe crop stops ticking");
            drops = net.minecraft.world.level.block.Block.getDrops(state, helper.getLevel(), helper.absolutePos(BlockPos.ZERO), null);
            helper.assertTrue(drops.stream().filter(stack -> stack.is(product)).mapToInt(ItemStack::getCount).sum() == (i == 0 ? 4 : 3),
                    "Ripe crops produce the configured yield bonus");
        }
        helper.succeed();
    }

    @GameTest
    public void sharedQuotaAndInvalidCustomersCannotDuplicateMoney(GameTestHelper helper) {
        GagoEntity merchant = helper.spawn(IntoxicantesMod.GAGO, new BlockPos(1, 1, 1));
        merchant.refreshTradeStock();
        var player = helper.makeMockServerPlayerInLevel();
        player.absSnapTo(merchant.getX(), merchant.getY(), merchant.getZ());
        player.getInventory().clearContent();
        player.getInventory().setItem(0, new ItemStack(IntoxicantesMod.UVA, 16));
        PlayerMoney.set(player, 0);
        helper.assertTrue(MarketTransactions.trade(player, merchant, 1, true) == MarketTransactions.Result.INVALID,
                "Trade without an active merchant session is rejected");
        merchant.setTradingPlayer(player);
        var entry = TradeCatalog.harvests().get(1);
        for (int i = 0; i < entry.stock() - 1; i++) merchant.marketInventory().consume(entry);
        helper.assertTrue(MarketTransactions.trade(player, merchant, 1, true) == MarketTransactions.Result.OK,
                "Last remaining quota can be used");
        helper.assertTrue(MarketTransactions.trade(player, merchant, 1, true) == MarketTransactions.Result.OUT_OF_STOCK,
                "Repeated request cannot exceed shared quota");
        helper.assertTrue(PlayerMoney.get(player) == 6 && player.getInventory().countItem(IntoxicantesMod.UVA) == 8,
                "Rejected repeat preserves money and remaining crop");
        helper.assertTrue(MarketTransactions.trade(player, merchant, -1, false) == MarketTransactions.Result.INVALID,
                "Negative index rejected");
        helper.assertTrue(MarketTransactions.trade(player, merchant, 99, false) == MarketTransactions.Result.INVALID,
                "Locked or nonexistent offers cannot be bought");
        merchant.setTradingPlayer(null);
        helper.succeed();
    }

    @GameTest
    public void harvestPaysExactlyAndRejectsShortPayment(GameTestHelper helper) {
        GagoEntity merchant = helper.spawn(IntoxicantesMod.GAGO, new BlockPos(1, 1, 1));
        merchant.refreshTradeStock();
        var player = helper.makeMockServerPlayerInLevel();
        player.absSnapTo(merchant.getX(), merchant.getY(), merchant.getZ());
        merchant.setTradingPlayer(player);
        PlayerMoney.set(player, 100);
        player.getInventory().clearContent();
        player.getInventory().setItem(0, new ItemStack(IntoxicantesMod.LOUPULO_FRESCO, 7));
        helper.assertTrue(MarketTransactions.trade(player, merchant, 0, true) == MarketTransactions.Result.NO_HARVEST,
                "Insufficient harvest must not pay");
        helper.assertTrue(PlayerMoney.get(player) == 100 && player.getInventory().getItem(0).getCount() == 7,
                "Rejected trade must preserve cash and harvest");
        player.getInventory().setItem(0, new ItemStack(IntoxicantesMod.LOUPULO_FRESCO, 4));
        player.getInventory().setItem(1, new ItemStack(IntoxicantesMod.LOUPULO_FRESCO, 8));
        helper.assertTrue(MarketTransactions.trade(player, merchant, 0, true) == MarketTransactions.Result.OK,
                "Full harvest is purchased across multiple inventory slots");
        helper.assertTrue(PlayerMoney.get(player) == 106, "Eight hops pay exactly six reais");
        helper.assertTrue(MarketTransactions.countHarvest(player, TradeCatalog.harvests().get(0)) == 4,
                "Exactly eight crops consumed");
        helper.assertTrue(MarketTransactions.trade(player, merchant, 0, false) == MarketTransactions.Result.OK,
                "Earned cash can buy a beverage");
        helper.assertTrue(PlayerMoney.get(player) == 91, "Beverage deducts the displayed price");
        helper.assertTrue(player.getInventory().countItem(IntoxicantesMod.CERVEJA) == 1,
                "Purchase delivers the item");
        merchant.setTradingPlayer(null);
        helper.succeed();
    }

    @GameTest
    public void beverageIngredientsPayCorrectBatchesWithoutResaleProfit(GameTestHelper helper) {
        var expected = java.util.List.of(IntoxicantesMod.LOUPULO_FRESCO, IntoxicantesMod.UVA,
                net.minecraft.world.item.Items.WHEAT, IntoxicantesMod.CANA_DE_ACUCAR,
                net.minecraft.world.item.Items.HONEY_BOTTLE, net.minecraft.world.item.Items.GLASS_BOTTLE);
        var ingredients = TradeCatalog.harvests();
        helper.assertTrue(ingredients.stream().map(TradeCatalog.Entry::item).toList().equals(expected),
                "Gago buys exactly the six ingredients used by his beverage recipes");
        var merchant = helper.spawn(IntoxicantesMod.GAGO, new BlockPos(1, 1, 1));
        merchant.refreshTradeStock();
        var player = helper.makeMockServerPlayerInLevel();
        player.absSnapTo(merchant.getX(), merchant.getY(), merchant.getZ());
        merchant.setTradingPlayer(player);
        PlayerMoney.set(player, 0);
        int balance = 0;
        for (int i = 0; i < ingredients.size(); i++) {
            var entry = ingredients.get(i);
            player.getInventory().clearContent();
            player.getInventory().setItem(0, new ItemStack(entry.item(), entry.count() - 1));
            helper.assertTrue(MarketTransactions.trade(player, merchant, i, true) == MarketTransactions.Result.NO_HARVEST,
                    "Each ingredient requires its own full batch");
            player.getInventory().setItem(0, entry.stack());
            helper.assertTrue(MarketTransactions.trade(player, merchant, i, true) == MarketTransactions.Result.OK,
                    "Each ingredient can be sold");
            balance += entry.price();
            helper.assertTrue(PlayerMoney.get(player) == balance && player.getInventory().countItem(entry.item()) == 0,
                    "Exact ingredients and containers are handed over, exact price paid");
            helper.assertTrue(merchant.marketInventory().remaining(entry) == entry.stock() - 1, "Only one quota consumed");
            for (var retail : TradeCatalog.gago(3)) if (retail.item() == entry.item()) {
                int discounted = Math.max(1, (int) Math.floor(retail.price() * 0.7));
                helper.assertTrue(discounted * entry.count() > entry.price() * retail.count(),
                        "Even maximum loyalty discount cannot profit from buying bottles to resell");
            }
        }
        merchant.setTradingPlayer(null);
        helper.succeed();
    }

    @GameTest
    public void everyPaymentFitsAndStreetPricesAreLower(GameTestHelper helper) {
        var shop = TradeCatalog.gago(0);
        helper.assertTrue(shop.size() == 18, "Retail includes seeds and UV reinvestment");
        HashSet<Item> seen = new HashSet<>();
        for (int seed = 0; seed < 100; seed++) {
            MerchantOffers street = TradeCatalog.traficante(RandomSource.create(seed), seed);
            helper.assertTrue(street.size() == 3, "Street dealer has exactly three offers");
            HashSet<Item> dailyItems = new HashSet<>();
            for (MerchantOffer offer : street) {
                Item item = offer.getResult().getItem();
                helper.assertTrue(dailyItems.add(item), "No duplicate street offer");
                seen.add(item);
                helper.assertTrue(offer.getMaxUses() == 4, "Street stock is scarce");
                for (var retail : shop) {
                    if (retail.item() == item) {
                        helper.assertTrue(offer.getCostA().getCount() < retail.price(),
                                "Street price must be lower than the market price");
                    }

                }
                for (var harvest : TradeCatalog.harvests()) {
                    if (harvest.item() == item) helper.assertTrue(offer.getCostA().getCount() * harvest.count() > harvest.price(),
                            "Buying to resell must not create free money");
                }
            }
        }
        helper.assertTrue(seen.size() == 7, "Rotation includes the entire street catalog");
        helper.succeed();
    }

    @GameTest
    public void restockAtSevenIsDeferredWhileTradingAndIgnoresRewind(GameTestHelper helper) {
        DailyTradeStock stock = new DailyTradeStock();
        MerchantOffers offers = stock.refresh(null, 1000, false, () -> TradeCatalog.traficante(RandomSource.create(7), 7L));
        offers.get(0).setToOutOfStock();
        helper.assertTrue(stock.refresh(offers, 24999, false, () -> TradeCatalog.traficante(RandomSource.create(7), 7L)) == offers,
                "No early refill before 07:00");
        helper.assertTrue(stock.refresh(offers, 25000, true, () -> TradeCatalog.traficante(RandomSource.create(7), 7L)) == offers,
                "An open trade keeps its offers stable");
        MerchantOffers next = stock.refresh(offers, 25000, false, () -> TradeCatalog.traficante(RandomSource.create(7), 7L));
        helper.assertFalse(next.get(0).isOutOfStock(), "Stock returns at 07:00 after trading ends");
        next.get(0).setToOutOfStock();
        helper.assertTrue(stock.refresh(next, 0, false, () -> TradeCatalog.traficante(RandomSource.create(7), 7L)) == next,
                "Rewinding time does not replenish stock");
        helper.assertTrue(stock.refresh(next, 25000, false, () -> TradeCatalog.traficante(RandomSource.create(7), 7L)) == next,
                "Repeating the same morning does not replenish stock");
        helper.assertTrue(DailyTradeStock.tradingDay(999) == -1 && DailyTradeStock.tradingDay(1000) == 0,
                "First-day boundary is exactly 07:00");
        helper.succeed();
    }

    @GameTest
    public void oldOffersMigrateWithoutRestoringUsedStock(GameTestHelper helper) {
        MerchantOffers old = new MerchantOffers();
        old.add(new MerchantOffer(new net.minecraft.world.item.trading.ItemCost(IntoxicantesMod.REAL, 15),
                new ItemStack(IntoxicantesMod.CERVEJA), 99, 0, 0.05F));
        for (int i = 0; i < 9; i++) old.get(0).increaseUses();
        MarketInventory stock = new MarketInventory();
        stock.refresh(1000, false, old);
        helper.assertTrue(stock.remaining(TradeCatalog.gago(0).get(0)) == 0, "Migration preserves spent stock");
        stock.refresh(1200, false, old);
        helper.assertTrue(stock.remaining(TradeCatalog.gago(0).get(0)) == 0, "Migration only runs once");
        stock.refresh(25000, true, old);
        helper.assertTrue(stock.remaining(TradeCatalog.gago(0).get(0)) == 0, "Open shop cannot restock");
        stock.refresh(25000, false, old);
        helper.assertTrue(stock.remaining(TradeCatalog.gago(0).get(0)) == 8, "Restock restores daily quota");
        helper.succeed();
    }

    @GameTest
    public void npcSaveReloadPreservesStockAndMerchantsAreIndependent(GameTestHelper helper) {
        GagoEntity first = helper.spawn(IntoxicantesMod.GAGO, new BlockPos(1, 1, 1));
        GagoEntity second = helper.spawn(IntoxicantesMod.GAGO, new BlockPos(3, 1, 1));
        first.refreshTradeStock();
        second.refreshTradeStock();
        var beer = TradeCatalog.gago(0).get(0);
        for (int i = 0; i < beer.stock(); i++) first.marketInventory().consume(beer);
        helper.assertTrue(second.marketInventory().remaining(beer) == 8, "Each merchant owns its stock");
        var output = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, helper.getLevel().registryAccess());
        first.saveWithoutId(output);
        var input = TagValueInput.create(ProblemReporter.DISCARDING, helper.getLevel().registryAccess(), output.buildResult());
        second.load(input);
        second.refreshTradeStock();
        helper.assertTrue(second.marketInventory().remaining(beer) == 0, "Reload must not refill used stock");
        TraficanteEntity dealer = helper.spawn(IntoxicantesMod.TRAFICANTE, new BlockPos(2, 1, 3));
        dealer.refreshTradeStock();
        dealer.getOffers().get(0).increaseUses();
        var streetOutput = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, helper.getLevel().registryAccess());
        dealer.saveWithoutId(streetOutput);
        Item originalItem = dealer.getOffers().get(0).getResult().getItem();
        dealer.load(TagValueInput.create(ProblemReporter.DISCARDING, helper.getLevel().registryAccess(), streetOutput.buildResult()));
        dealer.refreshTradeStock();
        helper.assertTrue(dealer.getOffers().get(0).getUses() == 1 && dealer.getOffers().get(0).getResult().is(originalItem),
                "Street selection and purchases survive reload");
        helper.succeed();
    }

    /** Registra no mapa estatico sem tocar em arquivo (get().set() gravaria no JSON). */
    private static void setSaldoTeste(ServerPlayer player, int valor) {
        try {
            var campo = PlayerMoney.class.getDeclaredField("moneyMap");
            campo.setAccessible(true);
            @SuppressWarnings("unchecked")
            java.util.Map<java.util.UUID, Integer> mapa = (java.util.Map<java.util.UUID, Integer>) campo.get(null);
            mapa.put(player.getUUID(), valor);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("moneyMap inacessivel", e);
        }
    }

    @GameTest
    public void balanceSaturatesAtCeilingAndNeverGoesNegative(GameTestHelper helper) {
        var player = helper.makeMockServerPlayerInLevel();
        // v1.2.2: 2.000.000.000 + 2.000.000.000 em int = saldo NEGATIVO que o set zerava
        setSaldoTeste(player, 2_000_000_000);
        PlayerMoney.add(player, 2_000_000_000);
        helper.assertTrue(PlayerMoney.get(player) == Integer.MAX_VALUE,
                "Overflow of add saturates at Integer.MAX_VALUE");
        PlayerMoney.add(player, 100);
        helper.assertTrue(PlayerMoney.get(player) == Integer.MAX_VALUE,
                "Ceiling holds after repeated additions");
        // /pagar (subtrair + add no destinatario) no limite: quem paga nunca fica negativo
        setSaldoTeste(player, 1_000_000_000);
        PlayerMoney.subtrair(player, 1_500_000_000);
        helper.assertTrue(PlayerMoney.get(player) == 1_000_000_000,
                "Payer without funds is untouched by subtrair");
        PlayerMoney.add(player, Integer.MAX_VALUE);
        helper.assertTrue(PlayerMoney.get(player) == Integer.MAX_VALUE,
                "Receiver of an enormous payment saturates instead of wrapping");
        PlayerMoney.add(player, -50);
        helper.assertTrue(PlayerMoney.get(player) == Integer.MAX_VALUE - 50,
                "Negative adjustment still works under saturation");
        helper.succeed();
    }

    /** Config de teste: troca a instancia em memoria (o config real no disco fica intocado). */
    private static void configDeTeste(ModConfig alteracoes) {
        try {
            var instancia = ModConfig.class.getDeclaredField("instancia");
            instancia.setAccessible(true);
            instancia.set(null, alteracoes);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("instancia inacessivel", e);
        }
    }

    /** Igual ao mock da GameTestHelper (perfil + connection embutida + placeNewPlayer),
     *  mas com gameMode() = SURVIVAL: o mock vanilla e' CREATIVE hardcoded na
     *  subclasse anonima, inalteravel por reflexao ou mutacao de campos. */
    private static ServerPlayer vitimaSobrevivente(GameTestHelper helper) {
        var level = helper.getLevel();
        var perfil = new com.mojang.authlib.GameProfile(java.util.UUID.randomUUID(), "vitima-teste");
        var cookie = net.minecraft.server.network.CommonListenerCookie.createInitial(perfil, false);
        ServerPlayer vitima = new ServerPlayer(level.getServer(), level, perfil, cookie.clientInformation()) {
            @Override
            public net.minecraft.world.level.GameType gameMode() {
                return net.minecraft.world.level.GameType.SURVIVAL;
            }
        };
        var conexao = new net.minecraft.network.Connection(net.minecraft.network.protocol.PacketFlow.SERVERBOUND);
        new io.netty.channel.embedded.EmbeddedChannel(conexao);
        level.getServer().getPlayerList().placeNewPlayer(conexao, vitima, cookie);
        // Complete the vanilla load handshake: unloaded clients are immune to damage.
        vitima.connection.handleAcceptPlayerLoad(new net.minecraft.network.protocol.game.ServerboundPlayerLoadedPacket());
        return vitima;
    }

    /** Injeta compras de fidelidade no mapa estatico sem tocar em arquivo. */
    private static void fidelidadeTeste(ServerPlayer player, int compras) {
        try {
            var campo = FidelidadeData.class.getDeclaredField("compras");
            campo.setAccessible(true);
            @SuppressWarnings("unchecked")
            java.util.Map<java.util.UUID, Integer> mapa = (java.util.Map<java.util.UUID, Integer>) campo.get(null);
            mapa.put(player.getUUID(), compras);
        } catch (ReflectiveOperationException e) {
            throw new AssertionError("compras inacessivel", e);
        }
    }

    /** Conquista concedida? (holder inexistente = dados de progressao quebrados) */
    private static boolean progresso(GameTestHelper helper, ServerPlayer player,
            net.minecraft.resources.Identifier id) {
        var holder = player.level().getServer().getAdvancements().get(id);
        helper.assertTrue(holder != null, "Advancement exists in the datapack: " + id);
        return holder != null && player.getAdvancements().getOrStartProgress(holder).isDone();
    }

    @GameTest
    public void loyaltyCardTiersAndAdvancementsProgressCorrectly(GameTestHelper helper) {
        var player = helper.makeMockServerPlayerInLevel();
        fidelidadeTeste(player, 0);
        helper.assertTrue(FidelidadeData.getTier(player) == 0 && FidelidadeData.descontoDe(player) == 0,
                "New customer starts on tier 0 with no discount");
        // 4 compras: ainda Fregues comum (a RAIZ sai ja na 1a compra; os tiers sao 5/15/30)
        for (int i = 0; i < 4; i++) {
            FidelidadeData.registrarCompra(player);
        }
        helper.assertTrue(FidelidadeData.getTier(player) == 0,
                "Four purchases stay on tier 0");
        helper.assertTrue(progresso(helper, player, Progressoes.RAIZ),
                "The very first purchase grants the root advancement");
        helper.assertFalse(progresso(helper, player, Progressoes.FREGUES_DA_ESQUINA),
                "Four purchases do not reach Fregues da Esquina");
        // 5a compra: Fregues da Esquina (tier 1, 5%) + raiz
        FidelidadeData.registrarCompra(player);
        helper.assertTrue(FidelidadeData.getTier(player) == 1 && FidelidadeData.descontoDe(player) == 5,
                "Five purchases reach tier 1 with 5% discount");
        helper.assertTrue(progresso(helper, player, Progressoes.RAIZ),
                "First purchase grants the root advancement");
        helper.assertTrue(progresso(helper, player, Progressoes.FREGUES_DA_ESQUINA),
                "Tier 1 grants Fregues da Esquina");
        helper.assertFalse(progresso(helper, player, Progressoes.DONO_DA_ESQUINA),
                "Tier 3 advancement is still locked");
        // pulo direto pro Dono da Esquina (30 compras, 15%)
        fidelidadeTeste(player, 29);
        FidelidadeData.registrarCompra(player);
        helper.assertTrue(FidelidadeData.getTier(player) == 3 && FidelidadeData.descontoDe(player) == 15,
                "Thirty purchases reach tier 3 with 15% discount");
        helper.assertTrue(progresso(helper, player, Progressoes.DONO_DA_ESQUINA),
                "Tier 3 grants Dono da Esquina");
        helper.assertTrue(FidelidadeData.precoComDesconto(player, 100) == 85,
                "Tier 3 discount prices a 100-real item at 85");
        helper.assertTrue(FidelidadeData.precoComDesconto(player, 1) == 1,
                "Discount never drops the price below one real");
        fidelidadeTeste(player, 0); // nao polui o JSON do mundo de teste
        helper.succeed();
    }

    @GameTest
    public void perfectHarvestAdvancementOnlyAtFullRipeness(GameTestHelper helper) {
        var player = helper.makeMockServerPlayerInLevel();
        var crop = (UvCropBlock) IntoxicantesMod.MACONHA_PLANT;
        // imatura (AGE 2, UV 0): colher NAO concede
        helper.setBlock(new BlockPos(3, 1, 1), net.minecraft.world.level.block.Blocks.FARMLAND);
        var verde = crop.defaultBlockState().setValue(UvCropBlock.AGE, 2).setValue(UvCropBlock.UV_AGE, 0);
        helper.setBlock(new BlockPos(3, 2, 1), verde);
        crop.playerWillDestroy(helper.getLevel(), helper.absolutePos(new BlockPos(3, 2, 1)), verde, player);
        helper.assertFalse(progresso(helper, player, Progressoes.COLHEITA_PERFEITA),
                "Harvesting an unripe crop grants nothing");
        // no ponto (AGE 4 + UV 3): concede
        helper.setBlock(new BlockPos(1, 1, 1), net.minecraft.world.level.block.Blocks.FARMLAND);
        var perfeita = crop.defaultBlockState().setValue(UvCropBlock.AGE, 4).setValue(UvCropBlock.UV_AGE, 3);
        helper.setBlock(new BlockPos(1, 2, 1), perfeita);
        crop.playerWillDestroy(helper.getLevel(), helper.absolutePos(new BlockPos(1, 2, 1)), perfeita, player);
        helper.assertTrue(progresso(helper, player, Progressoes.COLHEITA_PERFEITA),
                "Harvesting at AGE 4 + UV 3 grants Colheita Perfeita");
        helper.succeed();
    }

    @GameTest
    public void gagoShotgunFollowsConfigNotHardcodedValues(GameTestHelper helper) {
        ModConfig atual = ModConfig.get();
        ModConfig teste = new ModConfig();
        teste.escopetaCooldownTicks = 10;
        teste.escopetaDanoPorBalim = 0.5F;
        teste.escopetaBalins = 1;
        teste.escopetaAlcanceMaximo = 12;
        configDeTeste(teste);
        try {
            // canAttack() recusa alvo Player em dificuldade PACIFICA: o servidor de
            // game test nasce peaceful — NORMAL pra o Gago poder ficar puto kkkk
            helper.getLevel().getServer().setDifficulty(net.minecraft.world.Difficulty.NORMAL, true);
            GagoEntity gago = helper.spawn(IntoxicantesMod.GAGO, new BlockPos(1, 1, 1));
            // makeMockServerPlayerInLevel() devolve um mock cuja subclasse anonima
            // (GameTestHelper$3) SOBRESCREVE gameMode() pra devolver CREATIVE
            // hardcoded no bytecode: nenhuma mutacao no ServerPlayerGameMode muda
            // isso, e asValidTarget() descarta alvo criativo. Criamos um irmao do
            // mock do vanilla em modo sobrevivencia — mesmo padrao do helper.
            var vitima = vitimaSobrevivente(helper);
            vitima.absSnapTo(gago.getX() + 2, gago.getY(), gago.getZ());
            vitima.setPermanentlyInvulnerable(false);
            vitima.setInvulnerableTime(0);
            vitima.getAbilities().invulnerable = false; // Player.hurtServer recusa dano se true
            float vidaAntes = vitima.getHealth();
            gago.enraivecer(vitima);
            helper.assertTrue(gago.getTarget() == vitima,
                "Angered Gago targets the offender (survival mock)");
            helper.assertTrue(gago.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND).is(IntoxicantesMod.ESCOPETA),
                "Angered Gago draws the shotgun");
            // tiro direto via package-private: o tick do NPC dispararia sozinho,
            // mas o teste precisa do cooldown EXATO pra provar que vem do config
            gago.atirarEscopeta(vitima);
            helper.assertTrue(gago.cooldownTiro == teste.escopetaCooldownTicks,
                "Shotgun cooldown comes from the config (was hardcoded 60)");
            var area = helper.getLevel().getEntitiesOfClass(net.minecraft.world.entity.LivingEntity.class,
                    gago.getBoundingBox().inflate(teste.escopetaAlcanceMaximo));
            helper.assertTrue(vitima.getHealth() < vidaAntes,
                "Diagnostico dano: vida=" + vitima.getHealth() + "/" + vidaAntes
                    + " naArea=" + area.contains(vitima) + " totalArea=" + area.size()
                    + " dist=" + gago.distanceTo(vitima)
                    + " invEnt=" + vitima.isInvulnerable()
                    + " invAbi=" + vitima.getAbilities().invulnerable
                    + " invTemp=" + vitima.getInvulnerableTime()
                    + " morto=" + vitima.isDeadOrDying());
            // restabelece: a raiva passou, sem arma na mao, config original de volta
            gago.acalmar(vitima);
            helper.assertTrue(gago.getItemBySlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND).isEmpty(),
                "Calming the Gago puts the shotgun away");
        } finally {
            configDeTeste(atual);
        }
        helper.succeed();
    }
}
