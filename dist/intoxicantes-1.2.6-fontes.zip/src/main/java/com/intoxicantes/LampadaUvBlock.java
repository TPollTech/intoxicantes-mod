package com.intoxicantes;

import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * A Lampada UV: bloco de luz 15 que amadurece as plantacoes.
 * Alem de iluminar, ELA ZUMBE: hum eletrico ocasional (animateTick) — quem
 * ouve o zumbido de longe ja sabe que tem plantacao indoor na esquina kkkk.
 */
public class LampadaUvBlock extends Block {
    public LampadaUvBlock(Properties properties) {
        super(properties);
    }

    @Override
    public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
        // ~1 hum a cada 50s por lampada visivel: ambiente, nao karaoke kkkk
        if (random.nextFloat() < 0.02F) {
            level.playLocalSound(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    IntoxicantesMod.ZUMBIDO_UV, SoundSource.BLOCKS, 0.35F, 1.0F, false);
        }
    }
}
