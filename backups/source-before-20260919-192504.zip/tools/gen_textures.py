"""Gera texturas pixel-art (16x16) caprichadas: sombreamento em rampa,
contorno escuro automatico, brilhos e transparencias. Tambem gera modelos
de item e o icone do mod.

Uso: python tools/gen_textures.py  (executar a partir da raiz do projeto do mod)
"""
import json
import os
import struct
import zlib

ASSETS = os.path.join("src", "main", "resources", "assets", "intoxicantes")

def write_png(path, rows):
    h = len(rows)
    w = len(rows[0])
    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    raw = b"".join(b"\x00" + b"".join(bytes(px) for px in row) for row in rows)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))

def rgba(s, alpha=255):
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), alpha)

def render(map_lines, palette):
    rows = []
    for line in map_lines:
        assert len(line) == 16, "linha com %d colunas: %r" % (len(line), line)
        row = []
        for ch in line:
            if ch == ".":
                row.append((0, 0, 0, 0))
                continue
            v = palette[ch]
            row.append(v if isinstance(v, tuple) else rgba(v))
        assert len(row) == 16
        rows.append(row)
    assert len(rows) == 16
    return rows

def outline(rows, color_hex, alpha=255, min_solid=200):
    """Adiciona contorno escuro nos vizinhos transparentes dos pixels solidos."""
    col = rgba(color_hex, alpha)
    h, w = len(rows), len(rows[0])
    out = [list(r) for r in rows]
    for y in range(h):
        for x in range(w):
            if rows[y][x][3] != 0:
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and rows[ny][nx][3] >= min_solid:
                    out[y][x] = col
                    break
    return [tuple(p) for p in out]

def scale(rows, factor):
    out = []
    for row in rows:
        big = []
        for px in row:
            big.extend([px] * factor)
        out.extend([big] * factor)
    return out

# ---------------------------------------------------------------- texturas 16x16
# luz vindo do canto superior esquerdo; rampa clara->escura por material.

TEXTURES = {
    # Caneca de cerveja: espuma 2 tons, vidro com brilho, bolhas, alca sombreada
    "cerveja": (
        [
            "................",
            "....OOOOOO......",
            "...OOOOOOOOOO...",
            "...OfOOOFOOOo...",
            "....########....",
            "....GFFFFFFf....",
            "....Ggaaaaas....",
            "....GAaAAAaAh.h.",
            "....GaAAwAAah.h.",
            "....GaAAAAAah.h.",
            "....aAAAAAAahhh.",
            "....aaaaaaaa....",
            "....########....",
            "....#dddddd#....",
            "................",
            "................",
        ],
        {"O": "FDF8EA", "o": "E2D6B8", "F": "FFFDF4", "f": "E7DCBE", "#": "8A6B4A",
         "G": rgba("FFFFFF", 110), "g": "F7C868", "A": "E8940F", "a": "B85E08",
         "s": rgba("FFFFFF", 170), "w": "FFF6D8", "h": "6B4A2E", "H": "A87E4E",
         "d": "5A4632"},
        "2E1F10",
    ),
    # Taça de vinho: vidro translucido, vinho em rampa, reflexo no copo
    "vinho": (
        [
            "................",
            "................",
            "....EGGGGGGE....",
            "....EvVVVVVE....",
            "....ESvVVVxE....",
            "....ESVVVVxE....",
            ".....EVVVxE.....",
            "......EVxE......",
            ".......EE.......",
            ".......EE.......",
            ".......EE.......",
            ".......EE.......",
            ".....EsEEEE.....",
            "....EEEEEEEE....",
            "................",
            "................",
        ],
        {"E": "B9C7CE", "G": rgba("D7E4EA", 150), "S": rgba("FFFFFF", 200),
         "s": rgba("FFFFFF", 120), "v": "8E2A52", "V": "6E1B3C", "x": "4A1029"},
        "241820",
    ),
    # Garrafa de cachaça: vidro claro transparente, liquido branco, faixa vermelha
    "cachaca": (
        [
            "......KKKK......",
            "......KkkK......",
            "......EGGE......",
            "......EGGE......",
            ".....EGLLGE.....",
            "....EsLLLllE....",
            "....EsLLLllE....",
            "....EsLlLllE....",
            "....EsLlLllE....",
            "....ErRRRrrE....",
            "....ErRRRrrE....",
            "....EsbbbBlE....",
            "....EsLLLllE....",
            "....EEEEEEEE....",
            "................",
            "................",
        ],
        {"K": "C9CDD4", "k": "9AA0A8", "E": "AEBFC6", "G": (230, 240, 242, 110),
         "L": (248, 252, 252, 235), "l": (226, 240, 240, 235),
         "R": "D42A2A", "r": "A81F1F", "s": rgba("FFFFFF", 180), "b": "E8D9A0", "B": "C9B88A"},
        "1C2A30",
    ),
    # Jarra de hidromel: tampa de pano com corda, mel em degradado com bolha
    "hidromel": (
        [
            "................",
            "................",
            "...CCCCCCCCCC...",
            "...CcCCcCCcCC...",
            "....RrRrRrRr....",
            "....EsHHHhhE....",
            "....EsHHHhhE....",
            "....EshHdhhE....",
            "....EsHHdhhE....",
            "....EsHHHdhE....",
            "....EshHdhhE....",
            "....EsHHHhhE....",
            "....EddddddE....",
            "....EEEEEEEE....",
            "................",
            "................",
        ],
        {"C": "C9B88A", "c": "A89868", "R": "8A6A2E", "r": "6B5220",
         "E": "D9C9A0", "s": rgba("FFFFFF", 170), "H": "D89410", "h": "F0B62A", "d": "B87A0A"},
        "4A3210",
    ),
    # Garrafa de rum escura: vidro marrom transparencia, rotulo com selo
    "rum": (
        [
            "......KKKK......",
            "......KkkK......",
            "......EGGE......",
            "......EGGE......",
            ".....EDDDDE.....",
            "....EsDDDddE....",
            "....EsDDDddE....",
            "....EsDDDddE....",
            "....EbbbbbbE....",
            "....EbBxxbbE....",
            "....EbBxxbbE....",
            "....EbbbbbbE....",
            "....EsDDDddE....",
            "....EEEEEEEE....",
            "................",
            "................",
        ],
        {"K": "2B2B2E", "k": "17171A", "E": "241811", "G": (40, 28, 18, 140),
         "D": "6D3A1E", "d": "8A4A22", "s": (255, 230, 200, 90),         "b": "E8D9A0", "B": "C9B88A", "x": "4A2C1A"},
        "120B06",
    ),
    # Saco de papel com maconha: folha serrilhada em 3 tons
    "maconha_seda": (
        [
            "................",
            ".....tTTTt......",
            "...TTtTTTtTT....",
            "..TPlPlPlPlPt...",
            "..TPpLpLpLpPt...",
            "..TPPLpLpLPPT...",
            "..TPPLLpLPPT....",
            "..TPPPLpLPPPT...",
            "..TPPPPpPPPPT...",
            "...TPPPpPPPT....",
            "...TPPPpPPPT....",
            "....TPPpPPT.....",
            "....TTpppTT.....",
            ".....TTTTT......",
            "................",
            "................",
        ],
        {"T": "C9A876", "t": "A8854F", "P": "4C8C3A", "p": "2E6B22", "l": "8FD96A", "L": "B4EFA0"},
        "2A1C0E",
    ),
    # Baseado aceso: brasa em 2 tons, cinza, filtro de papelao e fumaca translucida
    "baseado": (
        [
            ".............m..",
            "............mM..",
            "...........MM...",
            "..........MM....",
            "................",
            "............ae..",
            "...........aFF..",
            "..........PaFF..",
            ".........PPFF...",
            "........PPPFF...",
            ".......BPPPFF...",
            "......BPPPPF....",
            ".....PPPPPPp....",
            "....kkPPPPPp....",
            "....a...........",
            "................",
        ],
        {"m": (190, 190, 205, 80), "M": (215, 215, 228, 130),
         "P": "EFE8D8", "p": "D9CFB8", "B": "FFFDF4",
         "a": "FF5A00", "e": "FF9E2A", "F": "B8B0A0", "k": "D9B98A"},
        "4A2410",
    ),
    # Saquinho plastico com po branco: brilho no plastico e montinho com relevos
    "cocaina": (
        [
            "................",
            "...EEEEEEEEEE...",
            "...E........E...",
            "...EsGGGGGGGE...",
            "...EsGGGGGGGE...",
            "...EGsGGGGGGE...",
            "...EGSWWWWWGE...",
            "...EWWWWWWWWWE..",
            "...EWWwWWWwWE...",
            "...EWwWwWWWwE...",
            "...EWxWwWxWWE...",
            "...EWxWWxWWWE...",
            "...EEEEEEEEEE...",
            "................",
            "................",
            "................",
        ],
        {"E": (190, 196, 210, 210), "G": (235, 238, 245, 70),
         "s": rgba("FFFFFF", 180), "S": "FFFFFF",
         "W": "F8F8FA", "w": "E8E8EE", "x": "D8D8E2"},
        "6A7080",
    ),
    # Seringa: corpo de vidro com brilho, liquido com janela vermelha, agulha metalica
    "heroina": (
        [
            "................",
            "...........MM...",
            "..........MMm...",
            ".........MMm....",
            ".....EEEEEEMm...",
            "....EsggggdM....",
            "....EsSggdEM....",
            "....EsRRgdE.....",
            "....EsgRgdE.....",
            "....EsgggdE.....",
            "....EEEEEE......",
            ".....Nn.........",
            "....Nn..........",
            "................",
            "................",
            "................",
        ],
        {"M": "C9CDD4", "m": "9AA0A8", "E": "B9C7CE",
         "s": rgba("FFFFFF", 200), "S": "FFFFFF", "g": (226, 244, 246, 200), "d": "6B7A80",
         "R": "D42A2A", "r": "A81F1F", "N": "C9CDD4", "n": "E8ECF0"},
        "2A3438",
    ),
    # Folha de LSD: 4 selos com arte, picotado no meio, sombra embaixo
    "lsd": (
        [
            "................",
            "................",
            "..MMMMMMMMMMMM..",
            "..MPPPPMMuuuuM..",
            "..MPyyPMMuPPuM..",
            "..MPyyPMMuPPuM..",
            "..MPPPPMMuuuuM..",
            "..mppppmppppm...",
            "..MccccMMPccPM..",
            "..McPPcMMPPccM..",
            "..McPPcMMPPccM..",
            "..MccccMMPPPPM..",
            "..MMMMMMMMMMMM..",
            "..mmmmmmmmmmmm..",
            "................",
            "................",
        ],
        {"M": "F5F3EA", "m": "C9C4B0", "p": "B8B29E",
         "P": "7B2FBE", "u": "9B4FD8", "y": "FFD447", "c": "3AB8FF", "k": "FF7AC8"},
        "4A4438",
    ),
    # Saco escuro com po estelar: po azulado com fagulhas ciano
    "po_estelar": (
        [
            "................",
            ".....tTTTt......",
            "...TTtTTTtTT....",
            "..TTPpPPsPPtT...",
            "..TTPPPPSPPtT...",
            "..TPpPPPPPptT...",
            "..TPsPPPPPPtT...",
            "..TPPPPPSPPtT...",
            "..TPpPPpPPPtT...",
            "..TPPPSPPPPtT...",
            "..TPPPPPPpPtT...",
            "...TPPPPPtT.....",
            "....tTTTTt......",
            "................",
            "................",
            "................",
        ],
        {"T": "2B3358", "t": "1E2440", "P": "3B4A8C", "p": "5568B8",
         "s": "7DF9FF", "S": "B8FDFF"},
        "10141F",
    ),
    # Saco de pano com nevoa do deserto: po claro com cintilancia verde-agua
    "nevoa_do_deserto": (
        [
            "................",
            ".....tTTTt......",
            "...TTtTTTtTT....",
            "..TTPpPPsPPtT...",
            "..TTPPPPSPPtT...",
            "..TPpPPPPPptT...",
            "..TPsPPPPPPtT...",
            "..TPPPPPSPPtT...",
            "..TPpPPpPPPtT...",
            "..TPPPSPPPPtT...",
            "..TPPPPPPpPtT...",
            "...TPPPPPtT.....",
            "....tTTTTt......",
            "................",
            "................",
            "................",
        ],
        {"T": "C9B896", "t": "A89868", "P": "D9CBA8", "p": "C9B888",
         "s": "9FE8DE", "S": "D8FFF8"},
        "3A3018",
    ),
    # Cogumelo xamanico: chapeu roxo com luminosidade, pontos brilhantes, hilos
    "cogumelo_xamanico": (
        [
            "................",
            "................",
            "....CCCCCCC.....",
            "...CPPuPPuPC....",
            "..CPuPPsPPuPC...",
            "..CPPPPPSPPPC...",
            "..CggggggggC....",
            ".....Ceeed......",
            "......eeed......",
            "......eeed......",
            "......eeed......",
            ".....CedddC.....",
            "................",
            "................",
            "................",
            "................",
        ],
        {"C": "4A2470", "P": "6B3FA0", "u": "8B5CF6", "g": "3A1F55",
         "s": "7DF9FF", "S": "B8FDFF", "e": "E8D9B0", "d": "C9B88A"},
        "1E102E",
    ),
    # Raiz de sombra: raiz diagonal com galhos, casca em rampa e corte claro
    "raiz_de_sombra": (
        [
            "................",
            "..........Ff....",
            ".........LRr....",
            "........LRr.....",
            ".......LRr...R..",
            "......LRr...LRr.",
            ".....LRr..LRr...",
            "....LRr..LRr....",
            "...LRr..LRr.....",
            "..LRr..LRr......",
            "..LRr...LRr.....",
            "...Lrr..........",
            "................",
            "................",
            "................",
            "................",
        ],
        {"F": "8A5A32", "f": "A5713F", "L": "6B4526", "R": "3E2723", "r": "2B1A10"},
        "140C08",
    ),
    # Cristal de euforia: cluster de 3 shards com facetas, brilho e fagulha
    "cristal_de_euforia": (
        [
            "................",
            ".......cc.......",
            "......ccPC......",
            "......cPPCD.....",
            ".....ccPPPCD.c..",
            ".....cSPPPCDcCD.",
            ".....ccPPPCDCD..",
            "..c...cPPCD.....",
            ".cCD..cPCD......",
            ".CD....cD.......",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
        ],
        {"c": "F9A8D4", "C": "831843", "P": "EC4899", "D": "5E0F2E",
         "S": "FFF0F8"},
        "40101F",
    ),
    # Vial de extrato de cafeina: tampa metal, vidro com brilho e cafe escuro
    "extrato_cafeina": (
        [
            "......KKKK......",
            "......KkkK......",
            "......KkkK......",
            ".....EGGGGE.....",
            "....EGGGGGGE....",
            "....EGGGGGGE....",
            "....EGGGGGGE....",
            "....EsBbbbbE....",
            "....EsBbbdbE....",
            "....EsBbbbbE....",
            "....EwBbdbbE....",
            "....EsBbbbbE....",
            "....EddddddE....",
            "....EEEEEEEE....",
            "................",
            "................",
        ],
        {"K": "7A8794", "k": "55606B", "E": "B9C7CE", "G": (220, 232, 236, 120),
         "s": rgba("FFFFFF", 190), "B": "6B4526", "b": "4A2C17", "d": "38200F", "w": "8A6A45"},
        "1C2630",
    ),
}

ITEMS = [
    "cerveja", "vinho", "cachaca", "hidromel", "rum",
    "maconha_seda", "baseado", "cocaina", "heroina", "lsd",
    "po_estelar", "cogumelo_xamanico", "nevoa_do_deserto",
    "raiz_de_sombra", "cristal_de_euforia", "extrato_cafeina",
]

def main():
    tex_dir = os.path.join(ASSETS, "textures", "item")
    items_dir = os.path.join(ASSETS, "items")

    for name, (map_lines, palette, outline_hex) in TEXTURES.items():
        rows = render(map_lines, palette)
        rows = outline(rows, outline_hex)
        write_png(os.path.join(tex_dir, name + ".png"), rows)

    # icone do mod: caneca de cerveja ampliada 4x (64x64)
    icon_rows = scale(render(*TEXTURES["cerveja"][:2]), 4)
    write_png(os.path.join(ASSETS, "icon.png"), icon_rows)

    # definicoes de modelo de item (formato novo, 1.21.4+/26.x)
    for name in ITEMS:
        model = {
            "model": {
                "type": "minecraft:model",
                "model": "intoxicantes:item/" + name,
            }
        }
        os.makedirs(items_dir, exist_ok=True)
        with open(os.path.join(items_dir, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(model, f, indent=2)

    # modelos classics apontando para a textura
    models_dir = os.path.join(ASSETS, "models", "item")
    for name in ITEMS:
        model = {
            "parent": "minecraft:item/generated",
            "textures": {"layer0": "intoxicantes:item/" + name},
        }
        os.makedirs(models_dir, exist_ok=True)
        with open(os.path.join(models_dir, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(model, f, indent=2)

    print("OK: %d texturas (com contorno e sombreamento), icon.png, %d modelos" % (len(TEXTURES), len(ITEMS)))

if __name__ == "__main__":
    main()
