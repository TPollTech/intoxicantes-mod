"""Gera texturas pixel-art dos itens de plantacao e da lampada UV.

Complementa o gen_textures.py (que mantem as texturas dos itens/bebidas).
Uso: python tools/gen_farm_textures.py  (a partir da raiz do projeto do mod)
"""
import os
import struct
import zlib

ASSETS = os.path.join("src", "main", "resources", "assets", "intoxicantes")

def write_png(path, rows):
    h = len(rows)
    w = len(rows[0])
    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xFFFFFFFF)
    ihdr = struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)
    raw = b"".join(b"\x00" + b"".join(bytes(px) for px in row) for row in rows)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", zlib.compress(raw)) + chunk(b"IEND", b""))

def rgba(s, alpha=255):
    return (int(s[0:2], 16), int(s[2:4], 16), int(s[4:6], 16), alpha)

def render(map_lines, palette):
    rows = []
    for line in map_lines:
        row = []
        for ch in line:
            if ch == ".":
                row.append((0, 0, 0, 0))
            else:
                v = palette[ch]
                row.append(v if isinstance(v, tuple) else rgba(v))
        rows.append(row)
    return rows

def outline(rows, color_hex, alpha=255):
    col = rgba(color_hex, alpha)
    h, w = len(rows), len(rows[0])
    out = [list(r) for r in rows]
    for y in range(h):
        for x in range(w):
            if rows[y][x][3] != 0:
                continue
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and rows[ny][nx][3] >= 200:
                    out[y][x] = col
                    break
    return [tuple(p) for p in out]

# ---------------------------------------------------------------- sementes (item)
# graozinhos soltos espalhados (estilo wheat_seeds vanilla)
def seed_tex(grao_esc, grao_claro):
    return (
        [
            "................",
            "................",
            "......S.........",
            ".....sSs........",
            "......s....S....",
            "..........sSs...",
            "...........s....",
            "....S...........",
            "...sSs..........",
            "....s...S.......",
            ".......sSs......",
            "........s.......",
            "................",
            "................",
            "................",
            "................",
        ],
        {"s": grao_esc, "S": grao_claro},
    )

# ---------------------------------------------------------------- estagios (bloco, cross)
def stage1(stem_d, stem_c, fruit):
    return (
        [
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
            "......gg........",
            ".....gggg.......",
            "....gg..gg......",
            ".....d..d.......",
            "......dd........",
            "......dd........",
            "................",
            "................",
            "................",
        ],
        {"g": stem_c, "d": stem_d},
    )

def stage2(stem_d, stem_c, fruit):
    return (
        [
            "................",
            "................",
            "................",
            "......g.g.......",
            ".....ggggg......",
            "....g..g..g.....",
            ".....g.g.g......",
            "......ggg.......",
            ".......d........",
            ".......d........",
            ".......d........",
            "......dd........",
            "......dd........",
            "................",
            "................",
            "................",
        ],
        {"g": stem_c, "d": stem_d},
    )

def stage3(stem_d, stem_c, fruit):
    return (
        [
            "................",
            "................",
            "....g...g.......",
            "...ggg.ggg......",
            "...g.ggg.g......",
            "....g.f.g.......",
            ".....gfg........",
            "......d.........",
            "....g.d.g.......",
            "...g..d..g......",
            "....g.d.g.......",
            "......dd........",
            "......dd........",
            "......dd........",
            "................",
            "................",
        ],
        {"g": stem_c, "d": stem_d, "f": fruit},
    )

def stage4(stem_d, stem_c, fruit):
    return (
        [
            "................",
            "....g...g.......",
            "...ggg.ggg.g....",
            "...g.ggg.gg.....",
            "..g.g.f.g.g.....",
            "..g.gfg.gg.g....",
            "...g.g.g.g......",
            "....gfgfg.......",
            ".....gfgf.......",
            "....gfgfg.......",
            "...g.gfg..g.....",
            "....g.g.g.......",
            "......dd........",
            "......dd........",
            "......dd........",
            "................",
        ],
        {"g": stem_c, "d": stem_d, "f": fruit},
    )

def stage4_ripe(stem_d, stem_c, fruit, ripe):
    """Mesma planta madura, mas com frutos 'uros' (prontos) e brilho."""
    mp, pal = stage4(stem_d, stem_c, fruit)
    pal = dict(pal)
    pal["f"] = ripe
    pal["H"] = (255, 255, 255, 230)
    lines = [list(line) for line in mp]
    for y, x in ((7, 6), (7, 8), (8, 8), (9, 6), (9, 8)):
        if lines[y][x] == "f":
            lines[y][x] = "H"
    return ["".join(line) for line in lines], pal

# culturas: nome -> (caule escuro, caule claro, fruto, fruto maduro, (semente escura, semente clara))
CROPS = {
    "maconha": ("3E2812", "4C8C3A", "6FBF4A", "B4EFA0", ("2E6B22", "8FD96A")),
    "lupulo": ("3E5A28", "5A8C3A", "8CC63F", "D4F07A", ("3E5A28", "9BD95A")),
    "uva": ("3E4A28", "5A7A3A", "8B5CF6", "D8B4FE", ("3E4A28", "B08CF0")),
    "cafe": ("4A3826", "6B5A3A", "C0392B", "E74C3C", ("4A3826", "D07050")),
    "papoula": ("2E4A20", "4A7A30", "D42A2A", "FF6B6B", ("2E4A20", "E86A6A")),
}

# ---------------------------------------------------------------- lampada UV (item/bloco)
LAMPADA_UV = (
    [
        "................",
        "....KKKKKKKK....",
        "...KxxxxxxxxK...",
        "...KxUUUUUUxK...",
        "...KxUvvvvUxK...",
        "...KxUvbbvUxK...",
        "...KxUvbWvUxK...",
        "...KxUvbbvUxK...",
        "...KxUvvvvUxK...",
        "...KxUUUUUUxK...",
        "...KxxxxxxxxK...",
        "....KKKKKKKK....",
        "................",
        "................",
        "................",
        "................",
    ],
    {"K": "2B2B2E", "x": "45454E", "U": "6B2FB8", "v": "8B5CF6",
     "b": "B4A0F0", "W": "E8DDFF"},
)

# ---------------------------------------------------------------- produtos (itens)
PRODUTOS = {
    "lupulo": (
        [
            "................",
            ".....ccc........",
            "....cCCCcc......",
            "...cCCsCCcc.....",
            "...cCsCCsCc.....",
            "....cCCsCcc.....",
            ".....cccc.......",
            "......cc........",
            "......Ss........",
            "......Ss........",
            "......ss........",
            "................",
            "................",
            "................",
            "................",
            "................",
        ],
        {"c": "7FA83A", "C": "A8CC5A", "s": "D4F07A", "S": "5A8C3A"},
    ),
    "uva": (
        [
            "................",
            ".......ss.......",
            "......s.........",
            "....vVv.vVv.....",
            "...vVVVvVvVv....",
            "...vVVvVVvVv....",
            "....vVvVVvV.....",
            "...vVvVVvVv.....",
            "....vVvVvV......",
            ".....vvvv.......",
            "................",
            "................",
            "................",
            "................",
            "................",
            "................",
        ],
        {"s": "5A7A3A", "v": "7B2FBE", "V": "9B4FD8"},
    ),
    "cafe_verde": (
        [
            "................",
            "................",
            "................",
            "......ccc.......",
            ".....cCCCc......",
            "....cCCsCCc.....",
            "....cCsCsCc.....",
            "....cCCsCCc.....",
            "....cCCCCCC.....",
            ".....cCCCc......",
            "......ccc.......",
            "................",
            "................",
            "................",
            "................",
            "................",
        ],
        {"c": "4A6B2A", "C": "7FA845", "s": "A8CC5A"},
    ),
    "cana_de_acucar": (
        [
            "................",
            "......gg........",
            ".....gGGg.......",
            "......gg........",
            ".....gGGg.......",
            "......gg........",
            ".....gGGg.......",
            "......gg........",
            ".....gGGg.......",
            "......gg........",
            ".....gGGg.......",
            "......gg........",
            ".....gGGg.......",
            "......gg........",
            "................",
            "................",
        ],
        {"g": "6B8C3A", "G": "A8CC7A"},
    ),
}

def main():
    tex_dir = os.path.join(ASSETS, "textures", "item")
    block_tex_dir = os.path.join(ASSETS, "textures", "block")
    count = 0

    # sementes (itens, com contorno)
    for crop, (sd, sc, fr, rf, (ge, gc)) in CROPS.items():
        rows = outline(render(*seed_tex(ge, gc)), "1A1410")
        write_png(os.path.join(tex_dir, "semente_" + crop + ".png"), rows)
        count += 1

    # lampada UV (item, com contorno)
    rows = outline(render(*LAMPADA_UV), "101014")
    write_png(os.path.join(tex_dir, "lampada_uv.png"), rows)
    count += 1

    # lampada UV (BLOCO): textura PLENA 16x16. A do item tem cantos transparentes
    # ( silhouette de icone ) — usada no cube_all virava "cubo de vidro" (bug do
    # print: se via o ceu atraves do bloco). Repete o painel 3x3: moldura escura
    # continua, nenhum pixel transparente.
    painel = render(*LAMPADA_UV)
    full = [[painel[2 + (y % 10)][2 + (x % 10)] for x in range(16)] for y in range(16)]
    write_png(os.path.join(block_tex_dir, "lampada_uv.png"), full)
    count += 1

    # produtos agricolas (itens, com contorno)
    for nome, (mp, pal) in PRODUTOS.items():
        rows = outline(render(mp, pal), "1A2010")
        write_png(os.path.join(tex_dir, nome + ".png"), rows)
        count += 1

    # estagios das culturas (blocos cross, SEM contorno)
    for crop, (sd, sc, fr, rf, _) in CROPS.items():
        for st, fn in ((1, stage1), (2, stage2), (3, stage3), (4, stage4)):
            rows = render(*fn(sd, sc, fr))
            write_png(os.path.join(block_tex_dir, "%s_stage%d.png" % (crop, st)), rows)
            count += 1
        rows = render(*stage4_ripe(sd, sc, fr, rf))
        write_png(os.path.join(block_tex_dir, crop + "_stage4_ripe.png"), rows)
        count += 1

    print("OK: %d texturas de farm geradas" % count)

if __name__ == "__main__":
    main()
