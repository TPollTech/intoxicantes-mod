# CHANGELOG - Intoxicantes Mod

---

## v1.1.1 — MERCADO FUNCIONAL DE VERDADE (19/09/2026)

### CORRIGIDO: NPCs ficam parados durante o comércio (rodada 8)
- **Gago e Traficante viram estatuetas enquanto a tela de troca está aberta**: IA congelada (`setNoAi`), navegação parada e velocidade zerada a cada tick de atendimento — o vendedor não passeia mais no meio da compra
- **MarketSystem não teleporta mais o Gago no meio do atendimento**: o gerenciador respeita `isTrading()` — a mudança de plantão (00:00, porta↔balcão) espera a tela fechar; o `stopTrading` devolve ele ao posto sozinho (ou ao passeio, se for Gago de ovo fora do mercado)
- **Gago PUTO não atende mais**: com a 12 na mão, clique-direito falha — faz sentido e evita abrir cardápio durante a perseguição
- Gancho no `stopTrading` (chamado pelo vanilla ao fechar a tela / afastar / morrer): restaura o estado certo — posto do mercado com IA travada, ou IA livre pra passear

### NOVO: Gago com fantasia temática por bioma (rodada 7)
- **7 roupas temáticas** (mesma cara bege do Rei do Bar, muda o tecido + um detalhe desenhado): **Plains** camisa vermelha clássica · **Deserto/Badlands** túnica de couro com cinto (Gago do Sertão) · **Selva** verde-mata com flor no peito · **Savanna** ocre do capim dourado com faixa de palha · **Neve** casaco azul-petróleo com botões (a "sede matriz" do Sul kkkk) · **Taiga/montanha** verde-pinho com faixa de lã · **Swamp** marrom-pantano com salpicos de lama
- A variante é **detectada no 1º tick do servidor** pelo bioma onde ele está (template/ovo/comando/save antigo — todos cobertos) e **gravada no NBT** (`Roupa`): o Gago mantém a roupa dele mesmo te perseguindo pra outro bioma — não troca de fantasia no meio da bronca
- Implementação: dado sincronizado próprio no servidor (`DATA_ROUPA`); no cliente o renderer o traduz pro **VillagerType vanilla** correspondente (os 7 tipos do vanilla = nossas 7 roupas) no campo `villagerData` do render state — o mesmo canal que o vanilla usa pra textura de vilarejo, sem subclassificar o render state (a `CrossedArmsItemLayer` exige o generics exato)
- Gerador `gen_npc_textures.py` refatorado: função `pintar_gago(tecido)` + tabela de 7 variantes com detalhes desenhados por região do torso

### NOVO: vida no mercado — Gago reage ao letreiro e a pedradas (rodada 6)
- **Ler o letreiro** (botão direito em qualquer placa perto do mercado, raio 24): o Gago cumprimenta o fregues — 3 falas novas em pt_br e en_us ("É issso aí! O melhor mercado da esquina, lêlogo lê!"), com partículas felizes e throttle de 8s (não vira spam)
- **Vandalismo** (soco/bomba em bloco num raio de 16 do mercado, jogador NÃO-criativo): o Gago **saca a 12 por 30 segundos** e vai atrás do vândalo — falas novas ("Vandalismo na MINHA esquina?! SACA A DOZE!"). Diferente do "gago" no chat (5 min de raiva total); passou os 30s, guarda a arma e volta ao balcão
- **Fix de oportunidade**: quando a raiva expirava, a 12 ficava na mão do Gago pra sempre (o código só adicionava a arma, nunca removia). Agora ele GUARDA a arma ao acalmar
- Eventos via `UseBlockCallback`/`AttackBlockCallback` (Fabric API), ambos com `PASS` — a edição da placa e o soco funcionam normal por cima

### CORRIGIDO DE VEZ: letreiro + dano da 12 (rodada 5, com prova empírica)
- **Letreiro — causa raiz achada por estatística do jar vanilla**: o NBT do texto da placa estava na **PALETA** do template, mas o `StructureTemplate` do 26.3 **só repassa o nbt da ENTRADA DE BLOCO** (`blocks[*].nbt`) — varredura dos 1511 templates vanilla: **0** casos na paleta, **5597** na entrada (baús de shipwreck etc). A placa sempre nascia SEM TEXTO. NBT movido pra entrada + validador agora REJEITA nbt na paleta
- **Letreiro — 2º bug**: a placa estava no plano da fachada (z9) com **ar atrás** (z8, interior) — wall_sign desanexa sem suporte e virava item caindo. Agora ela fica na FRENTE do alpendre (z10, x7, acima da porta, igual à foto) com a parede branca de suporte atrás; validador checa suporte de toda wall_sign (facing → bloco oposto tem que existir e não ser ar)
- **A 12 não dava dano em NADA**: o `getEntityHitResult` do vanilla varre alvos por **células de chunk no stream** — alvos finos (placas, falanges) escorriam entre células e o raio de 24 blocos não pegava NINGUÉM às vezes. Substituído por detector de **cone amostrado** (12 amostras por balim, teste esfera-AABB, vitima mais próxima leva — o balim "para" no que atravessa). Mesma coisa no tiro do Gago
- **Blindagem anti-invulnerável**: NPCs de saves antigos podiam estar gravados com `Invulnerable=1` — o `hurt` engole o dano SEM LOG nenhum (parece "não dá dano"). Agora: template grava `Invulnerable=0`, boot derruba o escudo de Gago/Traficante no load (`ServerEntityEvents.ENTITY_LOAD`), e o tiro derruba na hora se encontrar escudo (com warn no log)
- **Diagnóstico embutido**: cada tiro loga `[Escopeta] tiro: N balim(s) em M vitima(s)` — se algum dia "não der dano" de novo, o log diz exatamente onde a cadeia quebrou (0 balins = mira/AABB; vítima presente sem dano = escudo/source)
- **Perfuração de vidro generalizada**: trocado `TransparentBlock` (classe) por `isCollisionShapeFullBlock` (propriedade física) — pane/vidro/grade/barras NÃO são full-block e não travam chumbo; concreto cheio trava. Vale pro tiro do player e do Gago
- Mercado agora nasce em **37 biomas** (tag própria), incluindo neve — o bug "só na neve" ficou pra trás (confirmado pelo usuário)

### CORRIGIDO: rodada 4 do playtest (rebuild + biomas)
- **Mercado só nascia na NEVE**: o `structure/mercado_gago.json` apontava pra tag vanilla `#minecraft:has_structure/igloo` (referência copiada do igloo — o igloo só existe em bioma nevado!). Criada tag própria `#intoxicantes:has_structure/mercado_esquinao` com 21 biomas quentes/temperados (plains, savanna, desert, badlands, jungle, forest, beach...)
- **Validador aceita tags de bioma do próprio mod**: falso positivo travou o build anterior — ele só conhecia tags vanilla e rejeitava `#intoxicantes:...`. Agora valida tags do namespace do mod conferindo que o arquivo existe em `tags/worldgen/biome/`
- **`/gagomarket rebuild` não alterava nada**: o jar instalado era anterior às correções (o build quebrado no validador nunca foi instalado) e a versão do comando colocava o template com rotação NONE na âncora errada (7 blocos deslocado). Agora: âncora centro→origem com rotação derivada dos offsets persistidos

### CORRIGIDO: lote do playtest 3
- **Lâmpada UV virava cubo de vidro**: o model do BLOCO usava a textura do ITEM (ícone com cantos transparentes) — dava pra ver o céu através do bloco. Textura full-face dedicada (`textures/block/lampada_uv.png`, painel repetido 3×3) e model apontando pra ela
- **Escopeta deitada na mão**: o modelo era construído com o cano no +X (deitado); o display X=-90 do crossbow precisa de cano no +Y. Modelo remapeado `(x,y,z)→(z,x,y)` no gerador + display verbatim da besta vanilla — agora a arma fica EMPUNHADA (cano apontando pra onde mira, coronha pra baixo)
- **Gago desarmado por padrão**: só SACA a 12 quando ofendem ele; guarda de volta quando a raiva passa (o template NBT também não traz mais arma)
- **Escopeta não feria o Gago**: os balins paravam nos VIDROS da vitrine (clip do vanilla para em TransparentBlock) — agora o chumbo **perfura vidro/pane** (até 4 camadas), no tiro do player E no do Gago (ele atira através da vitrine de dentro)
- **`/gagomarket rebuild`**: estrutura gerada é imutável — chunks antigos NUNCA atualizam. O comando recoloca o template atual (letreiro, moldura, tudo) na posição do mercado do save
- **Porta desalinhada dos vidros**: moldura de concreto cinza (x2/x12) entre as colunas verdes e as vitrines — as panes conectam entre si e não "vazam" pro vão da porta

### CORRIGIDO: escopeta calibre 12 sem dano (rodada 2, playtest)
- **Escopeta do player**: os 8 balins voavam no mesmo tick e o vanilla rejeita dano repetido dentro dos i-frames (`invulnerableTime > 10`) — 7 dos 8 chumbinhos eram engolidos e a rajada virava um tapa de 3.0. Agora o dano é **acumulado por vítima** e aplicado de uma vez (até 24 de perto, decaindo pela dispersão natural)
- **Escopeta do Gago (pior)**: o raycast **excluía o próprio alvo** (`e != alvo`) — o tiro dele nunca podia acertar quem estava na mira, só quem passasse na frente do chumbo. Corrigido; mesmo esquema de dano acumulado

### POLIMENTO DO PLAYTEST (rodada 2)
- **Escopeta aponta pra frente** (1ª e 3ª pessoa): display agora usa a rotação X=-90 da besta/tridente vanilla (cano pro -Z, onde o player mira) em vez da diagonal de espada; ganhou ponto de mira vermelho na boca do cano
- **Gago saca a escopeta de verdade**: os renderers não tinham a `CrossedArmsItemLayer` (a camada que o WanderingTrader usa pra desenhar o item nas mãos cruzadas) — sem ela o heldItem nunca renderizava. Adicionada no Gago e no Traficante
- **Gago e Traficante interagíveis**: botão direito abre o cardápio (padrão `mobInteract` do WanderingTrader decifrado do bytecode). Causa raiz do "não abre": entidades de **template NBT não passam por `finalizeSpawn`** (confirmado no bytecode do StructureTemplate) — o Gago do mercado nascia com ofertas nulas; agora as ofertas são criadas sob demanda no primeiro clique
- **Letreiro do mercado de verdade**: formato de placa corrigido contra o igloo/bottom.nbt — `messages`/`filtered_messages` são TAG_List de 4 compounds `{text, color}` (não strings JSON; o texto JSON apareceria literal na placa). Letreiro "SUL / DISTRIBUIDORA / & MERCADO / ESQUINÃO" em verde escuro, glow ativo, igual à foto
- **Gago de pele bege**: a pele e o robe do villager têm a mesma paleta terrosa — o recolor por matiz pintava a cara junto com a camisa. Agora o recolor é POR REGIÃO da textura (y<16 = pele bege, y≥16 = camisa vermelha)

### CORRIGIDO CRÍTICO: crash ao abrir o inventário criativo
- `IllegalStateException: Accidentally adding the same item stack twice [Opium] to a Creative Mode Tab` — o Ópio entrou **duas vezes** na aba do mod (duplicata de uma correção anterior). Qualquer duplicata crasha a tela de inventário inteira. Removida; lista da aba revisada (sem outras duplicatas)

### NOVO: Mercado idêntico à referência (SUL DISTRIBUIDORA & MERCADO ESQUINÃO)
- Template reconstruído como **prédio de esquina de verdade** (15×5×11, 484 blocos): paredes de concreto verde, faixa superior branca, vitrines pretas com moldura, porta de abeto central, colunas de tronco de abeto, alpendre coberto na frente, piso interno de quartz polido e calçada de smooth stone
- **Placa de parede** na fachada com o nome em 4 linhas: `SUL / DISTRIBUIDORA / & MERCADO / ESQUINÃO` (voltada pra rua, texto NBT embutido na paleta do template)
- **Gago embutido no template** (entidade no NBT, nasce atrás do balcão junto com a estrutura — não depende mais só da descoberta por código)
- **NBT reescrito no formato real do 26.3** (decifrado direto dos templates vanilla): `size` = lista de 3 ints, `blocks` = lista de entradas `{pos, state}` (não o array legacy de índices), paleta com chave `id`. O formato antigo que o gerador escrevia **nunca geraria** no mundo
- Offsets do Gago (balcão **e** porta) giram junto com a rotação do jigsaw e persistem no NBT do save

### NOVO: Validador de worldgen nível 2
- Parser NBT completo (13 tipos) byte a byte, com **auto-teste contra o igloo vanilla** — se o parser estiver quebrado, o validador se auto-rejeita em vez de passar falso-positivo (bug real encontrado: `d[self.st()] = self.val(tt)` avalia o payload ANTES do nome em Python e dessincroniza o stream)
- Valida formato 26.3 do template: size/placa/entidades/paleta/pos, textos da placa (front_text/messages), entidade embutida com id

### NOVO: Validador automático de worldgen (`tools/validate_worldgen.py`)
- Roda em **todo `gradlew build`** (task `validateWorldgen`) e **falha o build** se achar referência órfã — nunca mais mundo travado em "Preparing for world creation"
- Valida contra o jar vanilla do cache do Loom (fonte da verdade, sobe de versão junto):
  - start_pool → template_pool, placed_feature → feature, structure_set → structure, processors
  - feature type / placement type / element_type (coletados dos JSONs vanilla da versão)
  - blocos e blockstates (`id[prop=valor]`) contra os blockstates do jar (variants + multipart)
  - tags de bloco e de bioma
  - NBT da estrutura: parse byte a byte, DataVersion cruzada com `version.json`, paleta, x*y*z, índices
- **Pegou um bug grave no dia 1**: o `blocks.data` do NBT do mercado era placeholder sequencial (o grid real nunca tinha sido encodado!) — corrigido no `gen_mercado.py`, agora codifica o layout ROWS[y][z][x] de verdade
- Teste de regressão: bug `minecraft:none` reinjetado → detectado com exit 1; restaurado → exit 0

### CORRIGIDO CRÍTICO: trava na criação de mundo
- O template_pool do mercado referenciava `"processors": "minecraft:none"` — esse valor **não existe** no 26.3 (a referência órfã derrubava o registry `worldgen/processor_list` inteiro com "Unbound values" e o jogo ficava preso em "Preparing for world creation"). Agora usa processors **inline** (`{"processors": []}`), igual aos pools vanilla, e `element_type: legacy_single_pool_element`

### CORRIGIDO: Assets quebrados (achados nos logs do jogo)
- **Escopeta invisível na mão**: o gerador escrevia UV em pixels da textura (0–32) mas model usa UV NORMALIZADO 0–16 — metade dos elementos fora do range, o jogo recusava o bake (`Cannot compute translucency out of bounds`). Corrigido na fonte (`gen_escopeta.py` divide por 2) e o preview agora lê UV normalizado também
- **R$ era um PNG truncado** (122 bytes, gerador da v1.1.0 morreu no meio): sprite nova de cédula verde (`tools/gen_real.py`)
- **Lâmpada UV rejeitada no block atlas**: o model de bloco usava textura da pasta `item/` (atlas errado no 26.3) — cópia criada em `textures/block/`

### POLIMENTO: o que já existia ficou redondo
- **Rotação do jigsaw respeitada**: a estrutura nasce girada aleatoriamente e a "porta" (onde o Gago atende de madrugada) agora acompanha a rotação real lida do piece — em 3 de 4 rotações ele ficaria de frente pro muro
- **Offset da porta persiste** no NBT (não se perde no reboot)
- **Traficante entrou na economia**: aceitava só esmeralda (ignorava o R$ inteiro) — agora cobra em R$ 10~20 por item, mais barato que o Gago (a rua é a rua), com estoque limitado; e passou a vender o Ópio
- **Gago se apresenta**: a frase de chegada existia mas ninguém chamava — agora ele fala pro freguês mais próximo ao nascer no posto
- **Escopeta fala**: click seco agora avisa na tela ("Click! Sem cartuchos...") e o tooltip ensina o reparo ("Repara com 2 Cartuchos na bigorna")
- **Escopeta reparável**: componente REPAIRABLE com cartuchos (2 cartuchos na bigorna restauram a durabilidade)
- **Versão do jar sincronizada**: `intoxicantes-1.1.1.jar` (era 1.0.0)

### CORRIGIDO: Sistema do Mercado (era o buraco da v1.1.0)
- **marketPos era estático e se perdia ao reiniciar** — agora salva em NBT (`intoxicantes_market.dat` no diretório do mundo) e carrega no boot
- **Auto-descoberta da estrutura**: se o admin nunca setou, o servidor acha a estrutura `mercado_gago` sozinho (espiral de chunks estilo /locate, raio 24 chunks do spawn, 1 tentativa a cada 30s)
- **A estrutura agora EXISTE de verdade**: a v1.1.0 prometia o NBT mas ele nunca foi criado. Template 11×4×9 gerado por código (DataVersion 5023), piso de andesite polido, balcão de slab com prateleira e canto de quartz, vitrine, lanterna, barril e fundação — o jigsaw rotaciona na geração
- Worldgen completo: `template_pool` + `structure` (jigsaw em superfície, terrain_adaptation beard_thin) + `structure_set` (spawn raro estilo igloo: spacing 40 / separation 22)
- **Gago do mercado tinha NoAI eterno** (estátua que nem reagia): agora tem IA de posto fixo — parado no balcão/porta, IA liberada quando fica puto (persegue, atira, volta pro posto quando a raiva passa)
- Gerenciador do Gago agora roda 1× a cada 5s (era 20×/s, spam de teleport)
- **Relógio do HUD errado**: usava `gameTime` (não avança com /time set). Agora usa o clock do overworld (API nova de clocks do 26.3)
- Âncora do Gago no PISO da estrutura (minY), não no meio do telhado

### NOVO: Economia fechada (item ↔ saldo)
- `/depositar` — deposita todo R$ do inventário no saldo virtual
- `/sacar <quantia>` — saca do saldo em R$ de inventário (o que não couber cai no chão)
- `/gagomarket set` agora salva na hora (não perde se o servidor cair)

### CORRIGIDO: Itens
- **ÓPIO era item invisível** (dropava da papoula sem sprite/model): sprite 16×16 de seiva dourada + model + receita (2 papoulas → 1 ópio)
- en_us.json: `itemGroup` ainda em português (regressão da v1.0.1)

### MELHORADO: Escopeta
- Durabilidade pela API vanilla (`hurtAndBreak`): som e lógica de quebra idênticos aos itens do jogo

### ARQUIVOS NOVOS
- `tools/gen_mercado.py` — gera todos os JSONs de worldgen + o template NBT
- `tools/gen_opio.py` — sprite do ópio
- `worldgen/template_pool/mercado_gago/start.json`, `worldgen/structure/mercado_gago.json`, `worldgen/structure_set/mercado_gago.json`
- `structure/mercado_gago.nbt` — **NÃO precisa mais criar em creative!**
- `texture/item/opio.png`, `models/item/opio.json`, `items/opio.json`, `recipe/opio.json`

### ARQUIVOS MODIFICADOS
- `MarketSystem.java` — reescrito: persistência NBT, descoberta de estrutura, throttle, clock correto, API 26.3
- `GagoEntity.java` — `setupPostoMercado()` (IA travada/solta), expulsão via getter
- `MoneyCommands.java` — `/depositar`, `/sacar`, save imediato no `/gagomarket set`
- `IntoxicantesMod.java` — `MarketSystem.load/save` no ciclo de vida, ópio na aba
- `EscopetaItem.java` — `hurtAndBreak`
- `en_us.json` — itemGroup em inglês

### NOTAS
- Mundo NOVO: a estrutura nasce perto do spawn (raio ~24 chunks) e o Gago aparece sozinho no balcão
- Mundo JÁ EXISTENTE: a estrutura só nasce em chunks nunca gerados — nesse caso use `/gagomarket set <x> <y> <z>` (ou ache um chunk inexplorado longe)
- O NBT do template foi validado byte a byte contra a spec de NBT (parser independente)

---

## v1.1.0 — MERCADO ESQUINAO DO GAGO (18/09/2026)

### NOVO: Sistema de Dinheiro R$
- Item `intoxicantes:real` — moeda do mercado, stackavel em 64
- Comandos: `/saldo`, `/pagar <player> <quantia>`, `/darreal <player> <quantia>` (op)
- Recipes: 1 Esmeralda = 1 R$, 9 R$ = 1 Bloco de Esmeralda
- Drops: Zumbis (15%) e Piglins (25%) dropam R$
- Gago dropa 5-20 R$ ao morrer

### NOVO: Sistema 24 Horas
- Gago atende o dia todo, nunca some
- De 07:00~00:00 fica no balcão (área principal)
- De 00:00~07:00 vai pra porta do mercado
- Anuncia quando muda de posição ("Vou fechar o balcão, vou atender na porta!")

### NOVO: Relogio no HUD
- Action bar mostra `14:30 | Mercado Esquinao no balcao` quando perto do mercado
- Atualiza a cada 10 segundos

### NOVO: Gago no Mercado
- Gago fica parado no balcao durante horario
- Cardapio com 12 itens todos em R$ (R$15 a R$100)
- Se chamar de "gago" dentro do mercado, ele te expulsa com teleport + porrada
- Escopeta sempre na mao durante raiva

### NOVO: Worldgen — Mercado Esquinao
- Estrutura gera em planicies e perto de vilas
- Template NBT: `data/intoxicantes/structure/mercado_gago.nbt` (CRIAR EM CREATIVE)
- JSONs de worldgen criados (structure + structure_set)

### ARQUIVOS NOVOS
- `RealItem.java` — classe do item R$
- `PlayerMoney.java` — persistencia JSON (saldo do player)
- `MoneyCommands.java` — registrador de comandos
- `MarketSystem.java` — horario + relogio + spawn do Gago
- `real.png` — textura placeholder do R$
- `items/real.json`, `models/item/real.json` — model do item
- `recipe/real_to_emerald.json` — 9 R$ = 1 bloco de esmeralda
- `recipe/emerald_to_real.json` — 1 bloco = 9 R$
- `recipe/emerald_to_real_single.json` — 1 esmeralda = 1 R$
- `recipe/real_to_emerald_single.json` — 1 R$ = 1 esmeralda
- `worldgen/structure/mercado_gago.json` — definicao da estrutura
- `worldgen/structure_set/mercado_gago.json` — placamento

### ARQUIVOS MODIFICADOS
- `IntoxicantesMod.java` — registrado REAL, comandos, market system, removido spawn aleatorio do Gago
- `GagoEntity.java` — cardapio em R$, falas de mercado, expulsao, drops de R$
- `pt_br.json` — traducoes novas (R$, fechando)
- `en_us.json` — traducoes novas (R$, closing)

### NOTAS
- O Traficante continua spawnando aleatoriamente
- Para criar a estrutura: constroa em creative, exporte com structure block como `mercado_gago.nbt`
- Coloque o arquivo em `data/intoxicantes/structure/mercado_gago.nbt`
- PlayerMoney usa JSON persistente (compativel com todas as versoes)

---

## v1.0.1 — CORRECOES DE BUGS

1. Crash Creative Tab duplicado (semente_maconha)
2. Gago nao despawnava (lag)
3. Traducoes en_us.json em portugues
4. Worldgen plantas inuteis (age=4 -> age=3)
5. Performance isUvLit (raio 3->2, sol primeiro)
6. CANA_DE_ACUCAR sem receita
7. Gago nao equipava escopeta ao ficar puto

---

**Creditos:** OpenCode (analise e implementacao)
**Autor do mod:** enzop
