# TODO - Intoxicantes Mod v1.1.0

## PENDENTE: Estrutura do Mercado no Mundo

### Criar o template .nbt (DENTRO DO JOGO)
1. Abra o Minecraft em **Creative Mode**
2. Constroi o Mercado do Gago como quiser (balcão, prateleira, parede, etc.)
3. Coloca um **Structure Block** no canto inferior esquerdo
4. Configura:
   - Mode: **Save**
   - Structure Name: `intoxicantes:mercado_gago`
   - Size: ajusta pro tamanho (ex: 13x8x11)
5. Clica em **Save**
6. O arquivo vai pra:
   ```
   saves/<seu_mundo>/generated/intoxicantes/structure/mercado_gago.nbt
   ```
7. Copia pra:
   ```
   src/main/resources/data/intoxicantes/structure/mercado_gago.nbt
   ```

### Depois de criar o .nbt
- Me avisa que eu configuro o worldgen pra gerar em vilarejos
- Os JSONs de worldgen ja estavam prontos (foram removidos por causa do crash)
- Vou recriar: structure + structure_set + ajuste pra spawnar em vilarejos

### Comando util
- `/gagomarket <x> <y> <z>` — seta a posição do mercado manualmente
- Gago aparece no local setado e fica 24h atendendo

---

## O que ja esta funcionando (v1.1.0)
- Sistema de dinheiro R$ (comando /saldo, /pagar, /darreal)
- Item R$ (real) com recipes
- Gago 24h no mercado (07:00-00:00 balcão, 00:00-07:00 porta)
- Cardápio do Gago em R$
- Expulsão quando chama de "gago" dentro do mercado
- Relogio na action bar perto do mercado
- Drops de R$ (Zumbis, Piglins, Gago)
- Persistência do saldo em JSON

---

## Créditos
- **Autor do mod:** enzop
- **Desenvolvimento:** OpenCode (Mimo v2.5)
