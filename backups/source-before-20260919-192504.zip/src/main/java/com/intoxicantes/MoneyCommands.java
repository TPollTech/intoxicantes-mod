package com.intoxicantes;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

public final class MoneyCommands {
    private MoneyCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(Commands.literal("saldo")
                    .requires(src -> src.isPlayer())
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                        int saldo = PlayerMoney.get(player);
                        player.sendSystemMessage(
                                Component.literal("\u00a76\u00a7lSeu saldo: \u00a7eR$ " + saldo));
                        player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.5F, 1.2F);
                        return Command.SINGLE_SUCCESS;
                    })
            );

            dispatcher.register(Commands.literal("pagar")
                    .requires(src -> src.isPlayer())
                    .then(Commands.argument("jogador", EntityArgument.player())
                            .then(Commands.argument("quantia", IntegerArgumentType.integer(1))
                                    .executes(ctx -> {
                                        ServerPlayer remetente = ctx.getSource().getPlayerOrException();
                                        ServerPlayer destinatario = EntityArgument.getPlayer(ctx, "jogador");
                                        int quantia = IntegerArgumentType.getInteger(ctx, "quantia");

                                        if (remetente == destinatario) {
                                            remetente.sendSystemMessage(
                                                    Component.literal("\u00a7c\u00a7lVoce nao pode pagar pra si mesmo!"));
                                            return 0;
                                        }
                                        if (!PlayerMoney.tem(remetente, quantia)) {
                                            remetente.sendSystemMessage(
                                                    Component.literal("\u00a7c\u00a7lSaldo insuficiente! Voce tem R$ " + PlayerMoney.get(remetente)));
                                            return 0;
                                        }

                                        PlayerMoney.subtrair(remetente, quantia);
                                        PlayerMoney.add(destinatario, quantia);

                                        remetente.sendSystemMessage(
                                                Component.literal("\u00a7a\u00a7lTransferido R$ " + quantia + " \u00a77pra \u00a7f" + destinatario.getName().getString()));
                                        destinatario.sendSystemMessage(
                                                Component.literal("\u00a7a\u00a7lRecebido R$ " + quantia + " \u00a77de \u00a7f" + remetente.getName().getString()));

                                        remetente.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.5F, 1.0F);
                                        destinatario.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.5F, 1.0F);

                                        IntoxicantesMod.LOGGER.info("[Dinheiro] {} pagou R$ {} pra {}",
                                                remetente.getName().getString(), quantia, destinatario.getName().getString());
                                        return Command.SINGLE_SUCCESS;
                                    })
                            )
                    )
            );

            dispatcher.register(Commands.literal("darreal")
                    .requires(src -> src.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER))
                    .then(Commands.argument("jogador", EntityArgument.player())
                            .then(Commands.argument("quantia", IntegerArgumentType.integer(1))
                                    .executes(ctx -> {
                                        ServerPlayer alvo = EntityArgument.getPlayer(ctx, "jogador");
                                        int quantia = IntegerArgumentType.getInteger(ctx, "quantia");
                                        PlayerMoney.add(alvo, quantia);
                                        alvo.sendSystemMessage(
                                                Component.literal("\u00a76\u00a7lVoce recebeu \u00a7eR$ " + quantia + " \u00a76do admin!"));
                                        alvo.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
                                        ctx.getSource().sendSuccess(
                                                () -> Component.literal("\u00a7aDeu R$ " + quantia + " pra " + alvo.getName().getString()),
                                                true);
                                        return Command.SINGLE_SUCCESS;
                                    })
                            )
                    )
            );

            dispatcher.register(Commands.literal("gagomarket")
                    .requires(src -> src.permissions().hasPermission(net.minecraft.server.permissions.Permissions.COMMANDS_GAMEMASTER))
                    .then(Commands.literal("set")
                            .then(Commands.argument("x", IntegerArgumentType.integer())
                                    .then(Commands.argument("y", IntegerArgumentType.integer())
                                            .then(Commands.argument("z", IntegerArgumentType.integer())
                                                    .executes(ctx -> {
                                                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                        int x = IntegerArgumentType.getInteger(ctx, "x");
                                                        int y = IntegerArgumentType.getInteger(ctx, "y");
                                                        int z = IntegerArgumentType.getInteger(ctx, "z");
                                                        BlockPos pos = new BlockPos(x, y, z);
                                                        MarketSystem.setMarketPosComando(ctx.getSource().getServer(), pos);
                                                        player.sendSystemMessage(
                                                                Component.literal("\u00a7a\u00a7lMercado Esquinao setado em X=" + x + " Y=" + y + " Z=" + z));
                                                        player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
                                                        IntoxicantesMod.LOGGER.info("[Market] Posicao setada por {}: {} {} {}",
                                                                player.getName().getString(), x, y, z);
                                                        return Command.SINGLE_SUCCESS;
                                                    })
                                            )
                                    )
                            )
                    )
                    .then(Commands.literal("rebuild")
                            .executes(ctx -> {
                                // Estrutura gerada e imutavel: chunks antigos NUNCA atualizam.
                                // Este comando recoloca o template (letreiro novo, moldura,
                                // vidros) na posicao do mercado do save atual.
                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                BlockPos p = MarketSystem.getMarketPos();
                                if (p == null) {
                                    player.sendSystemMessage(Component.literal(
                                            "\u00a7cMercado nao setado ainda. Use /gagomarket set <x> <y> <z>."));
                                    return 0;
                                }
                                ServerLevel level = ctx.getSource().getServer().overworld();
                                var tpl = level.getStructureTemplateManager().get(
                                        net.minecraft.resources.Identifier.fromNamespaceAndPath(
                                                IntoxicantesMod.MOD_ID, "mercado_gago"));
                                if (tpl.isEmpty()) {
                                    player.sendSystemMessage(Component.literal(
                                            "\u00a7cTemplate intoxicantes:mercado_gago nao encontrado!"));
                                    return 0;
                                }
                                // remove Gagos antigos da area (senao o rebuild empilha um
                                // novo por cima do que ja esta gravado no chunk)
                                for (GagoEntity velho : level.getEntitiesOfClass(GagoEntity.class,
                                        net.minecraft.world.phys.AABB.ofSize(
                                                net.minecraft.world.phys.Vec3.atCenterOf(p), 24, 12, 24))) {
                                    velho.discard();
                                }

                                // marketPos e o CENTRO do predio; placeInWorld quer a ORIGEM
                                // (canto 0,0,0 do template). E a rotacao tem que ser a MESMA
                                // que a estrutura original nasceu (os offsets do Gago/persistidos
                                // so fazem sentido nela) — derivamos a Rotation dos offsets.
                                int px = MarketSystem.getPortaOffset().getX();
                                int pz = MarketSystem.getPortaOffset().getZ();
                                net.minecraft.world.level.block.Rotation rot =
                                        (px == 0 && pz > 0) ? net.minecraft.world.level.block.Rotation.NONE
                                        : (px < 0 && pz == 0) ? net.minecraft.world.level.block.Rotation.CLOCKWISE_90
                                        : (px == 0 && pz < 0) ? net.minecraft.world.level.block.Rotation.CLOCKWISE_180
                                        : net.minecraft.world.level.block.Rotation.COUNTERCLOCKWISE_90;
                                net.minecraft.core.Vec3i tam = tpl.get().getSize(rot);
                                BlockPos origem = new BlockPos(
                                        p.getX() - tam.getX() / 2,
                                        p.getY(),
                                        p.getZ() - tam.getZ() / 2);

                                var settings = new net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings()
                                        .setRotation(rot)
                                        .setMirror(net.minecraft.world.level.block.Mirror.NONE)
                                        .setIgnoreEntities(false); // o Gago do template nasce junto
                                boolean ok = tpl.get().placeInWorld(level, origem, origem, settings,
                                        level.getRandom(), 2);
                                player.sendSystemMessage(Component.literal(
                                        "\u00a7a\u00a7lMercado reconstruido (rot " + rot + ") em X=" + origem.getX()
                                                + " Y=" + origem.getY() + " Z=" + origem.getZ()
                                                + (ok ? "" : " \u00a77(parcial: area pode nao estar carregada)")));
                                player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 1.0F, 0.8F);
                                IntoxicantesMod.LOGGER.info("[Market] rebuild executado por {} em {}",
                                        player.getName().getString(), p);
                                return Command.SINGLE_SUCCESS;
                            })
                    )
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                        BlockPos p = MarketSystem.getMarketPos();
                        if (p != null) {
                            player.sendSystemMessage(
                                    Component.literal("\u00a7e\u00a7lMercado em: X=" + p.getX() + " Y=" + p.getY() + " Z=" + p.getZ()));
                        } else {
                            player.sendSystemMessage(
                                    Component.literal("\u00a7cMercado nao setado ainda. Use /gagomarket set <x> <y> <z>"));
                        }
                        return Command.SINGLE_SUCCESS;
                    })
            );

            // /depositar: transforma todo R$ do inventario em saldo virtual
            dispatcher.register(Commands.literal("depositar")
                    .requires(src -> src.isPlayer())
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                        var inventario = player.getInventory();
                        int total = 0;
                        for (int i = 0; i < inventario.getContainerSize(); i++) {
                            ItemStack slot = inventario.getItem(i);
                            if (slot.is(IntoxicantesMod.REAL)) {
                                total += slot.getCount();
                                inventario.setItem(i, ItemStack.EMPTY);
                            }
                        }
                        if (total == 0) {
                            player.sendSystemMessage(
                                    Component.literal("\u00a7c\u00a7lVoce nao tem nenhum R$ no inventario!"));
                            return 0;
                        }
                        PlayerMoney.add(player, total);
                        player.sendSystemMessage(
                                Component.literal("\u00a7a\u00a7lDepositado R$ " + total + " \u00a77- saldo: \u00a7eR$ " + PlayerMoney.get(player)));
                        player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.7F, 1.4F);
                        return Command.SINGLE_SUCCESS;
                    })
            );

            // /sacar <quantia>: transforma saldo virtual em R$ de inventario
            dispatcher.register(Commands.literal("sacar")
                    .requires(src -> src.isPlayer())
                    .then(Commands.argument("quantia", IntegerArgumentType.integer(1))
                            .executes(ctx -> {
                                ServerPlayer player = ctx.getSource().getPlayerOrException();
                                int pediu = IntegerArgumentType.getInteger(ctx, "quantia");
                                int saldo = PlayerMoney.get(player);
                                if (saldo <= 0) {
                                    player.sendSystemMessage(
                                            Component.literal("\u00a7c\u00a7lSaldo zerado! Deposite R$ com /depositar."));
                                    return 0;
                                }
                                int quantia = Math.min(pediu, saldo);
                                PlayerMoney.subtrair(player, quantia);

                                // entrega em pilhas de 64; o que nao couber cai no chao
                                int restante = quantia;
                                while (restante > 0) {
                                    int pilha = Math.min(64, restante);
                                    restante -= pilha;
                                    ItemStack reais = new ItemStack(IntoxicantesMod.REAL, pilha);
                                    if (!player.getInventory().add(reais)) {
                                        player.drop(reais, false, net.minecraft.util.Prediction.PREDICTED);
                                    }
                                }
                                player.sendSystemMessage(
                                        Component.literal("\u00a7a\u00a7lSacado R$ " + quantia + " \u00a77- saldo: \u00a7eR$ " + PlayerMoney.get(player)));
                                player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.7F, 1.1F);
                                return Command.SINGLE_SUCCESS;
                            })
                    )
            );
        });
    }
}
