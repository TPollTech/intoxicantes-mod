package com.intoxicantes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

/**
 * Rede do Cardapio do Mercado Esquinao.
 *
 * O Gago NAO usa a UI de vilarejo vanilla: clique-direito abre uma tela propria
 * (EsquinaoCardapioScreen) alimentada por payload S2C; as compras voltam por
 * payload C2S e sao validadas SEMPRE no servidor (saldo, distancia, sessao).
 *
 * Sessao: enquanto a tela esta aberta, o player esta "em atendimento" no Gago
 * (setTradingPlayer — o Gago congela a IA). Um watchdog derruba a sessao se o
 * fregues correr longe, trocar de dimensao ou se o Gago morrer.
 */
public final class EsquinaoNetworking {
    /** Sessoes de atendimento abertas: UUID do fregues -> Gago que atende. */
    private static final Map<UUID, GagoEntity> SESSOES = new HashMap<>();

    private EsquinaoNetworking() {}

    // ==================================================== REGISTRO (common init: roda nos 2 lados)

    public static void register() {
        // Codecs (o registro e global na JVM: vale pros dois lados logados)
        PayloadTypeRegistry.playS2C().register(
                AbrirCardapioPayload.TYPE, AbrirCardapioPayload.STREAM_CODEC);
        PayloadTypeRegistry.playC2S().register(
                ComprarPayload.TYPE, ComprarPayload.STREAM_CODEC);
        PayloadTypeRegistry.playC2S().register(
                FecharCardapioPayload.TYPE, FecharCardapioPayload.STREAM_CODEC);

        // C2S: fregues clicou em COMPRAR (indice do cardapio)
        ServerPlayNetworking.registerGlobalReceiver(ComprarPayload.TYPE, (payload, ctx) -> {
            ServerPlayer player = ctx.player();
            GagoEntity gago = SESSOES.get(player.getUUID());
            if (gago == null || !gago.isAlive() || gago.isRemoved()
                    || gago.getTradingPlayer() != player
                    || player.distanceToSqr(gago) > 6.0 * 6.0) {
                return; // sem sessao valida: ignora (client desatualizado ou hack)
            }
            List<FidelidadeData.Entrada> cardapio = FidelidadeData.cardapioPara(player);
            int indice = payload.indice();
            if (indice < 0 || indice >= cardapio.size()) {
                return;
            }
            FidelidadeData.Entrada entrada = cardapio.get(indice);
            int preco = FidelidadeData.precoComDesconto(player, entrada.preco());
            if (!PlayerMoney.tem(player, preco)) {
                player.sendSystemMessage(Component.literal(
                        "\u00a7c\u00a7lSaldo insuficiente! Voce tem R$ " + PlayerMoney.get(player)
                                + " \u00a7c(e custa R$ " + preco + ")"));
                player.playSound(SoundEvents.VILLAGER_NO, 0.8F, 0.8F);
                return;
            }
            PlayerMoney.subtrair(player, preco);
            ItemStack item = entrada.item().copy();
            if (!player.getInventory().add(item)) {
                player.drop(item, false, net.minecraft.util.Prediction.PREDICTED);
            }
            FidelidadeData.registrarCompra(player);
            player.playSound(SoundEvents.EXPERIENCE_ORB_PICKUP, 0.7F, 1.4F);
            player.sendSystemMessage(Component.literal(
                    "\u00a7aComprou \u00a7f" + item.getHoverName().getString()
                            + " \u00a7apor R$ " + preco
                            + (FidelidadeData.descontoDe(player) > 0
                                    ? " \u00a77(fidelidade -" + FidelidadeData.descontoDe(player) + "%)"
                                    : "")));
            IntoxicantesMod.LOGGER.info("[Esquinao] {} comprou {} por R$ {}",
                    player.getName().getString(), item.getHoverName().getString(), preco);
            // reenvia o cardapio: precos/tier podem ter subido com a compra
            enviarCardapio(player, gago);
        });

        // C2S: fregues fechou a tela (Esc ou botao Fechar)
        ServerPlayNetworking.registerGlobalReceiver(FecharCardapioPayload.TYPE,
                (payload, ctx) -> encerrarSessao(ctx.player()));

        // Watchdog: fregues longe demais / mudou de dimensao / Gago morreu
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 10 != 0) {
                return; // a cada meio segundo basta
            }
            List<UUID> encerradas = null;
            for (Map.Entry<UUID, GagoEntity> sessao : SESSOES.entrySet()) {
                ServerPlayer player = server.getPlayerList().getPlayer(sessao.getKey());
                GagoEntity gago = sessao.getValue();
                boolean valida = player != null && gago != null && gago.isAlive()
                        && !gago.isRemoved()
                        && player.level() == gago.level()
                        && gago.getTradingPlayer() == player
                        && player.distanceToSqr(gago) <= 10.0 * 10.0;
                if (valida) {
                    continue;
                }
                if (encerradas == null) {
                    encerradas = new ArrayList<>();
                }
                encerradas.add(sessao.getKey());
                if (player != null) {
                    player.sendSystemMessage(Component.literal(
                            "\u00a77O Gago fechou o atendimento (voc\u00ea saiu do balc\u00e3o)."));
                    ServerPlayNetworking.send(player, new FecharCardapioPayload());
                }
                if (gago != null) {
                    gago.encerrarAtendimento();
                }
            }
            if (encerradas != null) {
                for (UUID uuid : encerradas) {
                    SESSOES.remove(uuid);
                }
            }
        });
    }

    // ==================================================== SESSAO

    /** Abre o atendimento: trava o Gago no balcao e manda o cardapio pro client. */
    public static void iniciarSessao(ServerPlayer player, GagoEntity gago) {
        GagoEntity anterior = SESSOES.get(player.getUUID());
        if (anterior != null && anterior != gago) {
            anterior.encerrarAtendimento();
        }
        SESSOES.put(player.getUUID(), gago);
        gago.setTradingPlayer(player);
        enviarCardapio(player, gago);
    }

    /** Monta e envia o cardapio do fregues (precos com o desconto do nivel). */
    public static void enviarCardapio(ServerPlayer player, GagoEntity gago) {
        List<FidelidadeData.Entrada> cardapio = FidelidadeData.cardapioPara(player);
        List<ItemStack> produtos = new ArrayList<>();
        List<Integer> precos = new ArrayList<>();
        List<Integer> precoCheio = new ArrayList<>();
        for (FidelidadeData.Entrada entrada : cardapio) {
            produtos.add(entrada.item());
            precoCheio.add(entrada.preco());
            precos.add(FidelidadeData.precoComDesconto(player, entrada.preco()));
        }
        int tier = FidelidadeData.getTier(player);
        int compras = FidelidadeData.getCompras(player);
        int proximoNivel = tier < FidelidadeData.META_TIER.length - 1
                ? FidelidadeData.META_TIER[tier + 1] : -1;
        ServerPlayNetworking.send(player, new AbrirCardapioPayload(
                tier, compras, proximoNivel, produtos, precos, precoCheio,
                FidelidadeData.INDICE_EXCLUSIVOS, PlayerMoney.get(player)));
    }

    /** Fecha o atendimento do fregues (Esc, botao Fechar ou watchdog). */
    public static void encerrarSessao(ServerPlayer player) {
        GagoEntity gago = SESSOES.remove(player.getUUID());
        if (gago != null) {
            gago.encerrarAtendimento();
        }
    }

    // ==================================================== PAYLOADS

    /** S2C: cardapio completo do Esquinao, ja com os precos do fidelidade. */
    public record AbrirCardapioPayload(int nivel, int compras, int comprasProximoNivel,
            List<ItemStack> produtos, List<Integer> precos, List<Integer> precoCheio,
            int primeiroExclusivo, int saldo) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<AbrirCardapioPayload> TYPE =
                CustomPacketPayload.createType("intoxicantes:abrir_cardapio");

        public static final StreamCodec<RegistryFriendlyByteBuf, AbrirCardapioPayload> STREAM_CODEC =
                CustomPacketPayload.codec(AbrirCardapioPayload::escrever, AbrirCardapioPayload::ler);

        private static void escrever(AbrirCardapioPayload p, RegistryFriendlyByteBuf buf) {
            ByteBufCodecs.VAR_INT.encode(buf, p.nivel);
            ByteBufCodecs.VAR_INT.encode(buf, p.compras);
            ByteBufCodecs.VAR_INT.encode(buf, p.comprasProximoNivel);
            ByteBufCodecs.VAR_INT.encode(buf, p.produtos.size());
            for (ItemStack item : p.produtos) {
                ItemStack.STREAM_CODEC.encode(buf, item);
            }
            for (int preco : p.precos) {
                ByteBufCodecs.VAR_INT.encode(buf, preco);
            }
            for (int preco : p.precoCheio) {
                ByteBufCodecs.VAR_INT.encode(buf, preco);
            }
            ByteBufCodecs.VAR_INT.encode(buf, p.primeiroExclusivo);
            ByteBufCodecs.VAR_INT.encode(buf, p.saldo);
        }

        private static AbrirCardapioPayload ler(RegistryFriendlyByteBuf buf) {
            int nivel = ByteBufCodecs.VAR_INT.decode(buf);
            int compras = ByteBufCodecs.VAR_INT.decode(buf);
            int proximo = ByteBufCodecs.VAR_INT.decode(buf);
            int tamanho = ByteBufCodecs.VAR_INT.decode(buf);
            List<ItemStack> produtos = new ArrayList<>(tamanho);
            for (int i = 0; i < tamanho; i++) {
                produtos.add(ItemStack.STREAM_CODEC.decode(buf));
            }
            List<Integer> precos = new ArrayList<>(tamanho);
            List<Integer> cheios = new ArrayList<>(tamanho);
            for (int i = 0; i < tamanho; i++) {
                precos.add(ByteBufCodecs.VAR_INT.decode(buf));
            }
            for (int i = 0; i < tamanho; i++) {
                cheios.add(ByteBufCodecs.VAR_INT.decode(buf));
            }
            int primeiroExclusivo = ByteBufCodecs.VAR_INT.decode(buf);
            int saldo = ByteBufCodecs.VAR_INT.decode(buf);
            return new AbrirCardapioPayload(nivel, compras, proximo, produtos,
                    precos, cheios, primeiroExclusivo, saldo);
        }

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** C2S: fregues clicou em Comprar no indice tal do cardapio. */
    public record ComprarPayload(int indice) implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<ComprarPayload> TYPE =
                CustomPacketPayload.createType("intoxicantes:comprar");

        public static final StreamCodec<RegistryFriendlyByteBuf, ComprarPayload> STREAM_CODEC =
                CustomPacketPayload.codec(
                        (p, buf) -> ByteBufCodecs.VAR_INT.encode(buf, p.indice()),
                        buf -> new ComprarPayload(ByteBufCodecs.VAR_INT.decode(buf)));

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    /** Nos dois sentidos: "fecha a tela do cardapio". Sem corpo. */
    public record FecharCardapioPayload() implements CustomPacketPayload {

        public static final CustomPacketPayload.Type<FecharCardapioPayload> TYPE =
                CustomPacketPayload.createType("intoxicantes:fechar_cardapio");

        public static final StreamCodec<RegistryFriendlyByteBuf, FecharCardapioPayload> STREAM_CODEC =
                CustomPacketPayload.codec(
                        (p, buf) -> {},
                        buf -> new FecharCardapioPayload());

        @Override
        public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }
}
