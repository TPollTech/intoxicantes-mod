package com.intoxicantes;

import net.minecraft.world.item.Item;

/**
 * Real (R$): moeda do Mercado Esquinão do Gago.
 * Empilhavel em 64,serve pra trocar com o Gago e entre players.
 */
public class RealItem extends Item {
    public RealItem(Properties properties) {
        super(properties);
    }
}
