package com.intoxicantes;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/**
 * Cultura que cresce em 5 estagios (age 0..4) e ainda precisa AMADURECER
 * sob luz forte (sol direto ou lampada UV) em 4 niveis (uv_age 0..3).
 * A colheita com uv_age=3 rende o produto de melhor qualidade.
 */
public class UvCropBlock extends CropBlock {
    public static final IntegerProperty AGE = IntegerProperty.create("age", 0, 4);
    public static final IntegerProperty UV_AGE = IntegerProperty.create("uv_age", 0, 3);

    private final boolean aceitaSoloComum;

    public UvCropBlock(Properties properties, boolean aceitaSoloComum) {
        super(properties);
        this.aceitaSoloComum = aceitaSoloComum;
    }

    @Override
    protected IntegerProperty getAgeProperty() {
        return AGE;
    }

    @Override
    public int getMaxAge() {
        return 4;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(AGE, UV_AGE);
    }

    @Override
    protected boolean mayPlaceOn(BlockState state, BlockGetter level, BlockPos pos) {
        if (aceitaSoloComum) {
            return state.is(net.minecraft.tags.BlockTags.DIRT) || state.is(Blocks.FARMLAND);
        }
        return super.mayPlaceOn(state, level, pos);
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        int age = state.getValue(AGE);
        if (age < getMaxAge()) {
            if (level.getRawBrightness(pos, 0) < 9) {
                return; // escuro demais: nao cresce
            }
            float speed;
            if (level.getBlockState(pos.below()).is(Blocks.FARMLAND)) {
                speed = getGrowthSpeed(this, level, pos);
            } else {
                speed = 0.15F; // solo comum: cresce mais devagar
            }
            if (IntoxicantesMod.isUvLit(level, pos)) {
                speed *= 2.0F; // lampada UV ou sol forte acelera o crescimento
            }
            if (random.nextFloat() < speed) {
                growCrops(level, pos, state);
            }
        } else {
            int uv = state.getValue(UV_AGE);
            if (uv < 3 && IntoxicantesMod.isUvLit(level, pos) && random.nextFloat() < 0.35F) {
                level.setBlock(pos, state.setValue(UV_AGE, uv + 1), 2);
            }
        }
    }
}
